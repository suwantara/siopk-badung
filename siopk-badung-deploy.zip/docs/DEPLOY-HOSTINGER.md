# Deploy SIOPK Badung — Hostinger Shared Hosting

**Domain**: `https://siopk.kbrc-bali.org`
**Server**: id-dci-web1632
**Tanggal**: 28 Juni 2026

---

## Spesifikasi Hosting

| Fitur | Nilai |
|-------|-------|
| Disk Space | 20 GB |
| RAM | 2048 MB |
| CPU Core | 1 |
| Inode | 400.000 |
| PHP Worker | 40 |
| Bandwidth | Unlimited |

---

## Struktur Folder

```
/home/u472709165/domains/siopk.kbrc-bali.org/
├── app/
├── bootstrap/
├── config/
├── database/
├── public/              ← isi Laravel
├── public_html/  → symlink ke public/
├── resources/
├── routes/
├── storage/
├── vendor/
├── .env
├── .htaccess
├── artisan
└── composer.json
```

---

## Konfigurasi Server

### PHP
- **Versi**: PHP 8.4
- **memory_limit**: 256M
- **max_execution_time**: 120
- **upload_max_filesize**: 10M
- **post_max_size**: 120M
- **max_file_uploads**: 20

### Database
- **Host**: `127.0.0.1`
- **Port**: `3306`
- **Database**: `u472709165_siopk_badung`
- **User**: `u472709165_systemsiopk`

### Document Root
`public_html/` → symlink ke `public/`

### SSL
Let's Encrypt (aktifkan via hPanel)

---

## .env Production

```ini
APP_NAME="SIOPK Badung"
APP_ENV=production
APP_KEY=    ← generated via php artisan key:generate
APP_DEBUG=false
APP_URL=https://siopk.kbrc-bali.org

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=u472709165_siopk_badung
DB_USERNAME=u472709165_systemsiopk
DB_PASSWORD="password"

FILESYSTEM_DISK=public
SESSION_DRIVER=file
SESSION_LIFETIME=120
SESSION_SECURE_COOKIE=true
SESSION_DOMAIN=.kbrc-bali.org
CACHE_STORE=file
QUEUE_CONNECTION=database
APP_LOCALE=id
APP_TIMEZONE=Asia/Makassar
LOG_CHANNEL=daily
LOG_LEVEL=warning

AI_PROVIDER=deepseek
DEEPSEEK_API_KEY=    ← isi key baru (key lama bocor di git)
FONNTE_TOKEN=         ← isi token baru (token lama bocor di git)
```

**Penting**: Password database yang mengandung `#` harus di-quote: `DB_PASSWORD="Siopk#26"`

---

## Cron Job

```
* * * * * /usr/local/bin/php /home/u472709165/domains/siopk.kbrc-bali.org/artisan queue:work --stop-when-empty --max-time=55 >> /dev/null 2>&1
```

Atau di hPanel:
- Menit: Every minute
- Jam: Every hour
- Hari: Every day
- Bulan: Every month
- Hari Kerja: Every weekday

---

## Perintah Deploy (SSH)

```bash
cd ~/domains/siopk.kbrc-bali.org

# Setup awal
cp .env.production .env
nano .env    # sesuaikan DB_PASSWORD & API keys
php artisan key:generate

# Dependencies
rm composer.lock
nano composer.json   # hapus "platform": { "php": "8.4.0" }
composer install --no-dev --optimize-autoloader

# Database
php artisan queue:table
php artisan migrate --force

# Storage
php artisan storage:link
mkdir -p storage/framework/views
mkdir -p storage/framework/sessions
mkdir -p storage/framework/cache/data
chmod -R 775 storage/framework

# Symlink public_html
rm -rf public_html
ln -s public public_html

# Optimize
php artisan config:cache && php artisan route:cache && php artisan view:cache

# Isi API Keys
nano .env   # DEEPSEEK_API_KEY=..., FONNTE_TOKEN=...
php artisan config:cache
```

---

## Update Kode

```bash
cd ~/domains/siopk.kbrc-bali.org
# Upload file baru / edit via File Manager

php artisan config:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan migrate --force   # jika ada migration baru
```

---

## Troubleshooting

| Masalah | Solusi |
|---------|--------|
| `composer install` gagal PHP version | `rm composer.lock && composer install --no-dev` |
| Database access denied | Password dengan `#` di-quote: `DB_PASSWORD="pass#word"` |
| `view:cache` error "View path not found" | `mkdir -p storage/framework/views` |
| Web masih ke public_html default | `rm -rf public_html && ln -s public public_html` |
