# SIOPK Badung — Layered Architecture Rewrite

> **Dokumen eksekusi untuk AI agent. Jangan menyimpang dari rencana ini.**
> Setiap phase wajib melalui double-check validation sebelum lanjut ke phase berikutnya.
> Setiap phase menghasilkan changelog singkat.

---

## ARSITEKTUR TARGET

```
┌──────────────────────────────────────────────────────┐
│ PRESENTATION LAYER                                   │
│ Controllers (THIN, ≤30 lines, hanya orchestration)   │
│ FormRequests (SEMUA write operations)                │
│ View Composers                                        │
└───────────────┬──────────────────────────────────────┘
                │ inject Actions + Repositories
┌───────────────▼──────────────────────────────────────┐
│ APPLICATION LAYER                                     │
│ Actions/ (single-purpose, satu class per use case)   │
│ → Business logic, transactions, event dispatch       │
└───────────────┬──────────────────────────────────────┘
                │ call Services + Repositories
┌───────────────▼──────────────────────────────────────┐
│ DOMAIN LAYER                                          │
│ Services/ (domain logic, business rules, AI)          │
│ Models/ (Eloquent: scopes, relations, casts ONLY)     │
│ Enums/ (single source of truth, digunakan di SEMUA)   │
└───────────────┬──────────────────────────────────────┘
                │ accessed via Repositories
┌───────────────▼──────────────────────────────────────┐
│ INFRASTRUCTURE LAYER                                  │
│ Repositories/ (data access abstraction)              │
│ Jobs/ (queue workers)                                 │
│ Events/ + Listeners/ (domain events)                  │
└──────────────────────────────────────────────────────┘
```

### Aturan Mutlak

1. **Controllers** — tidak boleh ada Eloquent query langsung, tidak boleh ada business logic, tidak boleh ada `DB::transaction()`, tidak boleh ada `Cache::` calls. Hanya: validate → Action → response.
2. **Actions** — satu class per use case. Handle transaction, orchestration, event dispatch. Tidak boleh akses `Request` object. Terima DTO/array/primitives, return value object atau void.
3. **Services** — domain logic, business rules. Tidak boleh menerima `Request`. Terima domain objects/primitives.
4. **Repositories** — hanya data access. Query building, filtering, pagination. Return `Collection`, `Paginator`, atau single Model.
5. **Models** — hanya relationships, scopes, casts, accessors. Tidak boleh ada facade calls (`Cache`, `DB`, `Http`, `Log`).
6. **FormRequests** — WAJIB untuk setiap write operation. Tidak boleh ada inline `$request->validate()` di controller.
7. **Enums** — WAJIB digunakan di semua layer. Tidak boleh ada raw string untuk nilai yang ada enum-nya.
8. **Cache keys** — WAJIB pakai `App\Helpers\CacheKeys` constants. Tidak boleh hardcoded string.
9. **Tidak boleh mengubah route definitions** — backward compatible. URL, method, name tidak berubah.
10. **Tidak boleh mengubah Blade views** — data yang dikirim ke view harus sama struktur dan namanya.
11. **Setiap perubahan harus verify dengan `php artisan test`** (atau subset test yang relevan) sebelum lanjut.

---

## PRASYARAT: Folder Structure Baru

Sebelum Phase 0 dimulai, buat direktori berikut:

```
app/Actions/
app/Actions/Opk/
app/Actions/Media/
app/Actions/User/
app/Actions/Wilayah/
app/Actions/Kategori/
app/Actions/Ai/
app/Actions/Export/
app/Repositories/
```

---

## PHASE 0 — FOUNDATION

**Tujuan**: Stabilkan base layer. Semua phase berikutnya bergantung pada ini.

### 0.1 — Enum Consolidation

**Status saat ini**: Enum didefinisikan tapi hanya `OpkLaporan` model yang menggunakannya. Services, Jobs, Requests, Controllers pakai raw strings.

#### Task 0.1a — `StatusVerifikasi` enum usage

Cari dan ganti semua raw string `'menunggu'`, `'ai_review'`, `'review_dinas'`, `'disetujui'`, `'ditolak'`, `'duplikat'` dengan `StatusVerifikasi::NamaCase->value` di file berikut:

| File | Raw strings yang harus diganti |
|------|-------------------------------|
| `app/Http/Requests/StoreLaporanRequest.php` | (jika ada rule `in:...` untuk status) |
| `app/Services/LaporanService.php` | Line ~47: `'status_verifikasi' => 'menunggu'` |
| `app/Services/VerifikasiService.php` | Lines 16,21: `'disetujui'`, `'ditolak'`, `'duplikat'`; Line 47: `'Disetujui oleh verifikator.'` |
| `app/Jobs/AnalisisOpkJob.php` | Lines 48,62,68,86,97: `'ai_review'`, `'review_dinas'` |
| `app/Console/Commands/AnalisisSemuaOpkCommand.php` | Line ~17: `IN ['menunggu', 'review_dinas', 'disetujui']` |
| `app/Services/OpkStatsService.php` | Lines ~19,21,22: `'disetujui'`, `'menunggu'`, `'review_dinas'` |
| `app/Http/Controllers/Publik/DashboardPublikController.php` | Line ~53: `'disetujui'` comparison |
| `app/Http/Controllers/Admin/VerifikasiController.php` | (cek apakah ada raw string) |
| `app/Events/LaporanVerified.php` | Constructor param `$status` — tetap string, tapi consumer pakai enum |

**Cara ganti**: Tambah `use App\Enums\StatusVerifikasi;` di atas, lalu ganti string jadi `StatusVerifikasi::Disetujui->value`.

#### Task 0.1b — `KondisiOpk` enum usage

Ganti raw string `'baik'`, `'waspada'`, `'kritis'` di:

| File | Lokasi |
|------|--------|
| `app/Http/Requests/StoreLaporanRequest.php` | Rule `in:baik,waspada,kritis` |
| `app/Http/Requests/UpdateOpkRequest.php` | Rule `in:baik,waspada,kritis` |
| `app/Services/AiOpkAnalyzer.php` | Lines ~267-285 (fallback heuristic): `'kritis'`, `'waspada'` |
| `app/Services/PetaDataService.php` | Cek filter kondisi |
| `app/Http/Controllers/Publik/DashboardPublikController.php` | `orderByRaw('FIELD(kondisi, ...)')` |

#### Task 0.1c — `UserRole` enum usage

Ganti raw string `'superadmin'`, `'admin'`, `'verifikator'`, `'petugas'` di:

| File | Lokasi |
|------|--------|
| `app/Models/User.php` | Lines ~32-49: helper methods `isAdmin()`, `isSuperAdmin()`, dsb. — ganti string comparison jadi `UserRole::Nama->value` |
| `app/Http/Requests/StoreUserRequest.php` | Rule `in:superadmin,admin,verifikator,petugas` |
| `app/Http/Middleware/RoleMiddleware.php` | Line ~28: `in_array($user->role, $roles)` — route parameter string tetap bisa dibandingkan dengan enum values |
| `routes/web.php` | `role:superadmin,admin,verifikator,petugas` — **tetap string**, tidak perlu diubah karena ini route definition |

#### Task 0.1d — `AiProvider` enum usage

Cek dan pastikan `AiProviderFactory` dan `config/services.php` konsisten. `AiProvider::cases()` atau `AiProvider::tryFrom()` digunakan di factory.

#### Double Check 0.1

```bash
# 1. Cari sisa raw string yang seharusnya pakai enum
grep -rn "'menunggu'\|\"menunggu\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'disetujui'\|\"disetujui\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'ditolak'\|\"ditolak\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'ai_review'\|\"ai_review\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'review_dinas'\|\"review_dinas\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'kritis'\|\"kritis\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'waspada'\|\"waspada\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'baik'\|\"baik\"" app/ --include="*.php" | grep -v "Enums/"
grep -rn "'superadmin'\|\"superadmin\"" app/ --include="*.php" | grep -v "Enums/" | grep -v "web.php"
grep -rn "'admin'\|\"admin\"" app/Models/User.php
grep -rn "'verifikator'\|\"verifikator\"" app/Models/User.php

# 2. Run tests
php artisan test
```

---

### 0.2 — Repository Layer

Buat 7 Repository class. Setiap Repository menerima dependencies via constructor injection (tidak pakai facade).

#### 0.2a — `App\Repositories\OpkLaporanRepository`

```php
namespace App\Repositories;

use App\Models\OpkLaporan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;

class OpkLaporanRepository
{
    public function getDisetujui(array $filters = [], int $perPage = 12): LengthAwarePaginator
    {
        return OpkLaporan::with(['kategori', 'kecamatan', 'desaDinas', 'fotoUtama'])
            ->disetujui()
            ->when($filters['kategori_id'] ?? null, fn($q, $v) => $q->where('kategori_id', $v))
            ->when($filters['kecamatan_id'] ?? null, fn($q, $v) => $q->where('kecamatan_id', $v))
            ->when($filters['kondisi'] ?? null, fn($q, $v) => $q->where('kondisi', $v))
            ->when($filters['search'] ?? null, fn($q, $v) => $q->where('nama_opk', 'like', "%{$v}%"))
            ->when(($filters['sort'] ?? null) === 'prioritas',
                fn($q) => $q->orderByRaw("FIELD(kondisi, 'kritis','waspada','baik')")->orderByDesc('ai_urgency_score')
            )
            ->latest()
            ->paginate($perPage);
    }

    public function getMenunggu(array $filters = [], int $perPage = 20): LengthAwarePaginator
    {
        return OpkLaporan::with(['kategori', 'kecamatan', 'desaDinas'])
            ->menunggu()
            ->when($filters['kategori_id'] ?? null, fn($q, $v) => $q->where('kategori_id', $v))
            ->when($filters['kecamatan_id'] ?? null, fn($q, $v) => $q->where('kecamatan_id', $v))
            ->when($filters['search'] ?? null, fn($q, $v) => $q->where('nama_opk', 'like', "%{$v}%"))
            ->latest()
            ->paginate($perPage);
    }

    public function getArsip(int $perPage = 20): LengthAwarePaginator
    {
        return OpkLaporan::onlyTrashed()
            ->with(['kategori', 'kecamatan'])
            ->latest('deleted_at')
            ->paginate($perPage);
    }

    public function findWithRelations(int $id): ?OpkLaporan
    {
        return OpkLaporan::with([
            'kategori', 'kecamatan', 'desaDinas', 'verifikator',
            'fotos', 'fotoUtama', 'dokumens', 'videos', 'riwayat.user'
        ])->find($id);
    }

    public function findByKode(string $kode): ?OpkLaporan
    {
        return OpkLaporan::with(['kategori', 'kecamatan', 'desaDinas', 'fotoUtama'])
            ->where('kode_laporan', $kode)
            ->first();
    }

    public function findTrashed(int $id): ?OpkLaporan
    {
        return OpkLaporan::withTrashed()->find($id);
    }

    public function findOnlyTrashed(int $id): ?OpkLaporan
    {
        return OpkLaporan::onlyTrashed()->find($id);
    }

    public function getPrioritas(int $limit = 10): Collection
    {
        return OpkLaporan::with(['kategori', 'kecamatan', 'fotoUtama'])
            ->disetujui()
            ->prioritas()
            ->orderByDesc('ai_urgency_score')
            ->limit($limit)
            ->get();
    }

    public function getAntrian(int $limit = 7): Collection
    {
        return OpkLaporan::with(['kategori', 'kecamatan'])
            ->menunggu()
            ->latest()
            ->limit($limit)
            ->get();
    }

    public function getPetaData(): Collection
    {
        return OpkLaporan::with(['kategori', 'kecamatan', 'desaDinas', 'fotoUtama'])
            ->disetujui()
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->where('latitude', '!=', 0)
            ->where('longitude', '!=', 0)
            ->get();
    }

    public function getLatestDisetujui(int $limit = 6): Collection
    {
        return OpkLaporan::with(['kategori', 'kecamatan', 'fotoUtama'])
            ->disetujui()
            ->latest()
            ->limit($limit)
            ->get();
    }

    public function getTrenBulanan(int $bulan = 6): Collection
    {
        // pindahkan query raw SQL dari LaporanAdminController ke sini
        // raw SQL dengan DB::raw() untuk GROUP BY bulan
        // return Collection setelah ->get()->map()
    }

    public function suggest(string $query, int $limit = 10): Collection
    {
        return OpkLaporan::with(['kecamatan'])
            ->disetujui()
            ->where('nama_opk', 'like', "%{$query}%")
            ->limit($limit)
            ->get();
    }
}
```

#### 0.2b — `App\Repositories\OpkCategoryRepository`

```php
namespace App\Repositories;

use App\Models\OpkCategory;
use Illuminate\Database\Eloquent\Collection;

class OpkCategoryRepository
{
    public function getAll(): Collection
    {
        return OpkCategory::orderBy('nomor')->get();
    }

    public function getWithOpkCount(): Collection
    {
        return OpkCategory::withCount(['laporans' => fn($q) => $q->disetujui()])
            ->orderByDesc('total')
            ->get();
    }

    public function find(int $id): ?OpkCategory { ... }
    public function create(array $data): OpkCategory { ... }
    public function update(OpkCategory $kategori, array $data): bool { ... }
    public function delete(OpkCategory $kategori): bool { ... }
}
```

#### 0.2c — `App\Repositories\KecamatanRepository`

```php
namespace App\Repositories;

use App\Models\Kecamatan;
use Illuminate\Database\Eloquent\Collection;

class KecamatanRepository
{
    public function getAll(): Collection
    {
        return Kecamatan::orderBy('nama')->get();
    }

    public function getWithDesaAndOpkCount(): Collection
    {
        return Kecamatan::withCount(['desaDinas', 'desaAdats', 'laporans' => fn($q) => $q->disetujui()])
            ->orderBy('nama')
            ->get();
    }

    public function getWithOpkCount(): Collection
    {
        return Kecamatan::withCount(['laporans' => fn($q) => $q->disetujui()])
            ->orderByDesc('total')
            ->get();
    }

    public function findWithDesa(int $id): ?Kecamatan
    {
        return Kecamatan::with(['desaDinas' => fn($q) => $q->orderBy('nama'), 'desaAdats' => fn($q) => $q->orderBy('nama')])
            ->find($id);
    }

    public function find(int $id): ?Kecamatan { ... }
    public function create(array $data): Kecamatan { ... }
    public function update(Kecamatan $kecamatan, array $data): bool { ... }
    public function delete(Kecamatan $kecamatan): bool { ... }
}
```

#### 0.2d — `App\Repositories\DesaDinasRepository`

```php
namespace App\Repositories;

use App\Models\DesaDinas;
use Illuminate\Database\Eloquent\Collection;

class DesaDinasRepository
{
    public function getByKecamatan(int $kecamatanId): Collection
    {
        return DesaDinas::where('kecamatan_id', $kecamatanId)->orderBy('nama')->get();
    }

    public function find(int $id): ?DesaDinas { ... }
    public function create(array $data): DesaDinas { ... }
    public function update(DesaDinas $desaDinas, array $data): bool { ... }
    public function delete(DesaDinas $desaDinas): bool { ... }
}
```

#### 0.2e — `App\Repositories\DesaAdatRepository`

```php
namespace App\Repositories;

use App\Models\DesaAdat;
use Illuminate\Database\Eloquent\Collection;

class DesaAdatRepository
{
    public function getByKecamatan(int $kecamatanId): Collection
    {
        return DesaAdat::where('kecamatan_id', $kecamatanId)->orderBy('nama')->get();
    }

    public function find(int $id): ?DesaAdat { ... }
    public function create(array $data): DesaAdat { ... }
    public function update(DesaAdat $desaAdat, array $data): bool { ... }
    public function delete(DesaAdat $desaAdat): bool { ... }
}
```

#### 0.2f — `App\Repositories\UserRepository`

```php
namespace App\Repositories;

use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class UserRepository
{
    public function getFiltered(array $filters = [], int $perPage = 15): LengthAwarePaginator
    {
        return User::query()
            ->when($filters['search'] ?? null, fn($q, $v) => $q->where(function($sq) use ($v) {
                $sq->where('name', 'like', "%{$v}%")
                   ->orWhere('email', 'like', "%{$v}%");
            }))
            ->when($filters['role'] ?? null, fn($q, $v) => $q->where('role', $v))
            ->latest()
            ->paginate($perPage);
    }

    public function find(int $id): ?User { ... }
    public function create(array $data): User { ... }
    public function update(User $user, array $data): bool { ... }
    public function delete(User $user): bool { ... }
}
```

#### 0.2g — `App\Repositories\OpkRiwayatRepository`

```php
namespace App\Repositories;

use App\Models\OpkRiwayatStatus;

class OpkRiwayatRepository
{
    public function create(array $data): OpkRiwayatStatus
    {
        return OpkRiwayatStatus::create($data);
    }
}
```

**Register di `AppServiceProvider::register()`**:

```php
$this->app->singleton(OpkLaporanRepository::class);
$this->app->singleton(OpkCategoryRepository::class);
$this->app->singleton(KecamatanRepository::class);
$this->app->singleton(DesaDinasRepository::class);
$this->app->singleton(DesaAdatRepository::class);
$this->app->singleton(UserRepository::class);
$this->app->singleton(OpkRiwayatRepository::class);
```

#### Double Check 0.2

```bash
# Pastikan semua Repository ter-register
grep -rn "Repository::class" app/Providers/AppServiceProvider.php

# Pastikan tidak ada Repository yang pakai facade Cache/Http/Log
grep -rn "Cache::\|Http::\|Log::" app/Repositories/

# Run tests
php artisan test
```

---

### 0.3 — Fix Hardcoded Cache Keys

Ganti semua `Cache::forget('kecamatan_with_desa')`, `Cache::forget('kecamatan_list')`, `Cache::forget('kategori_list')` dengan `CacheKeys` constants di file berikut:

| File | String saat ini | Ganti dengan |
|------|----------------|-------------|
| `app/Http/Controllers/Admin/DesaAdatController.php` | `'kecamatan_with_desa'` | `CacheKeys::KECAMATAN_WITH_DESA` |
| `app/Http/Controllers/Admin/DesaDinasController.php` | `'kecamatan_with_desa'` | `CacheKeys::KECAMATAN_WITH_DESA` |
| `app/Http/Controllers/Admin/KecamatanController.php` | `'kecamatan_list'`, `'kecamatan_with_desa'` | `CacheKeys::KECAMATAN_LIST`, `CacheKeys::KECAMATAN_WITH_DESA` |
| `app/Http/Controllers/Admin/KategoriController.php` | `'kategori_list'` | `CacheKeys::KATEGORI_LIST` |
| `app/Http/Controllers/Admin/WilayahController.php` | `'kecamatan_list'`, `'kecamatan_with_desa'` | `CacheKeys::KECAMATAN_LIST`, `CacheKeys::KECAMATAN_WITH_DESA` |

Tambahkan `use App\Helpers\CacheKeys;` import di setiap file.

#### Double Check 0.3

```bash
# Pastikan tidak ada hardcoded cache key yang tersisa
grep -rn "Cache::forget\|Cache::remember\|Cache::get\|Cache::put" app/Http/Controllers/ | grep -v "CacheKeys::"
# (boleh ada Cache:: calls, asalkan valuenya pakai CacheKeys constant, bukan string literal)

# Cek 5 controller sudah import CacheKeys
grep "use App\\Helpers\\CacheKeys" app/Http/Controllers/Admin/DesaAdatController.php
grep "use App\\Helpers\\CacheKeys" app/Http/Controllers/Admin/DesaDinasController.php
grep "use App\\Helpers\\CacheKeys" app/Http/Controllers/Admin/KecamatanController.php
grep "use App\\Helpers\\CacheKeys" app/Http/Controllers/Admin/KategoriController.php
grep "use App\\Helpers\\CacheKeys" app/Http/Controllers/Admin/WilayahController.php
```

---

### 0.4 — Resolve Duplicate Controllers

**Masalah**: `WilayahController` (135 lines) dan `KecamatanController` + `DesaDinasController` + `DesaAdatController` duplikat fungsionalitas.

**Cek route**: `routes/web.php` line 124-135 menunjukkan route `/admin/wilayah/*` menggunakan `KecamatanController`, `DesaDinasController`, `DesaAdatController`. `WilayahController` TIDAK digunakan di route manapun.

#### Action

1. **Hapus** `app/Http/Controllers/Admin/WilayahController.php`
2. **Verifikasi** route tidak ada yang referensi `WilayahController`

```bash
grep -rn "WilayahController" routes/ app/
```

#### Double Check 0.4

```bash
php artisan route:list | grep wilayah
# Harus return route yang menggunakan KecamatanController, DesaDinasController, DesaAdatController
# Tidak boleh ada referensi ke WilayahController

php artisan test --filter=AdminWilayahTest
```

---

### 0.5 — Delete Dead Interfaces

**Masalah**: 4 interface di `app/Contracts/` tidak di-implement oleh service class manapun dan tidak di-inject oleh controller manapun. Dead code.

#### Action

Hapus:
- `app/Contracts/LaporanServiceInterface.php`
- `app/Contracts/OpkStatsServiceInterface.php`
- `app/Contracts/PetaDataServiceInterface.php`
- `app/Contracts/VerifikasiServiceInterface.php`

Hapus binding dari `AppServiceProvider::register()`:

```php
// HAPUS 4 baris ini:
$this->app->bind(OpkStatsServiceInterface::class, OpkStatsService::class);
$this->app->bind(PetaDataServiceInterface::class, PetaDataService::class);
$this->app->bind(LaporanServiceInterface::class, LaporanService::class);
$this->app->bind(VerifikasiServiceInterface::class, VerifikasiService::class);
```

Hapus import terkait di `AppServiceProvider`.

#### Double Check 0.5

```bash
grep -rn "Interface" app/Http/Controllers/ | grep -i "contracts\|laporan\|opkstats\|peta\|verifikasi"
# Harus kosong — tidak ada controller yang type-hint ke interface tersebut

php artisan test
```

---

### CHANGELOG — PHASE 0

```
## Phase 0 — Foundation — YYYY-MM-DD

### Added
- 7 Repository classes (OpkLaporan, OpkCategory, Kecamatan, DesaDinas, DesaAdat, User, OpkRiwayat)
- Repository registrations in AppServiceProvider

### Changed
- Enum consolidation: StatusVerifikasi, KondisiOpk, UserRole values used across all layers
- All hardcoded cache keys replaced with CacheKeys constants
- Service classes now `use` enum references instead of raw strings

### Removed
- 4 dead Contract interfaces (LaporanServiceInterface, OpkStatsServiceInterface, PetaDataServiceInterface, VerifikasiServiceInterface)
- WilayahController (duplicate, unused in routes)
- Dead interface bindings in AppServiceProvider

### Fixed
- 5 controllers: hardcoded cache key strings → CacheKeys constants
```

---

## PHASE 1 — ACTION CLASSES

**Tujuan**: Ekstrak business logic dari controllers/services ke single-purpose Action classes.

**Pola Action Class**:
```php
namespace App\Actions\Opk;

class CreateLaporanAction
{
    public function __construct(
        private LaporanService $laporanService,
        private OpkLaporanRepository $laporanRepo,
    ) {}

    public function execute(array $validated): OpkLaporan
    {
        return DB::transaction(function () use ($validated) {
            $laporan = $this->laporanService->createLaporan($validated);

            if (!empty($validated['fotos'] ?? [])) {
                $this->laporanService->uploadFotos($laporan, $validated['fotos'], $validated['keterangan_foto_utama'] ?? null);
            }

            if (!empty($validated['dokumen'] ?? null)) {
                $this->laporanService->uploadDokumen($laporan, $validated['dokumen']);
            }

            if (!empty($validated['link_video'] ?? null)) {
                $this->laporanService->saveVideoLink($laporan, $validated['link_video']);
            }

            return $laporan;
        });
    }
}
```

### 1.1 — Create Action Classes

Buat file berikut dengan isi sesuai deskripsi. **Sumber logic diambil dari controller/service yang ditunjuk. Pindahkan logic, jangan duplikat.**

| # | Action Class | Sumber Logic | Method `execute` |
|---|-------------|-------------|-----------------|
| 1.1a | `Actions/Opk/CreateLaporanAction.php` | `LaporController::store()` + `LaporanService` | `execute(array $validated): OpkLaporan` — DB transaction: create laporan + upload fotos + upload dokumen + save video |
| 1.1b | `Actions/Opk/SubmitLaporanAction.php` | `LaporController::store()` bagian dispatch | `execute(OpkLaporan $laporan): void` — dispatch AnalisisOpkJob + LaporanCreated event |
| 1.1c | `Actions/Opk/UpdateOpkAction.php` | `OpkController::update()` | `execute(OpkLaporan $laporan, array $validated): OpkLaporan` — DB transaction: update fields + kelola media |
| 1.1d | `Actions/Opk/SoftDeleteOpkAction.php` | `OpkController::destroy()` | `execute(OpkLaporan $laporan): void` — soft delete |
| 1.1e | `Actions/Opk/RestoreOpkAction.php` | `OpkController::restore()` | `execute(int $id): OpkLaporan` — restore from trash |
| 1.1f | `Actions/Opk/ForceDeleteOpkAction.php` | `OpkController::forceDelete()` | `execute(int $id): void` — force delete |
| 1.1g | `Actions/Opk/SetujuiLaporanAction.php` | `VerifikasiController::setujui()` + `VerifikasiService::setujuiLaporan()` | `execute(OpkLaporan $laporan, User $verifikator, ?string $catatan): void` |
| 1.1h | `Actions/Opk/TolakLaporanAction.php` | `VerifikasiController::tolak()` + `VerifikasiService::tolakLaporan()` | `execute(OpkLaporan $laporan, User $verifikator, string $alasan, string $catatan): void` |
| 1.1i | `Actions/Opk/UpdateAiScoreAction.php` | `VerifikasiController::updateAiScore()` | `execute(OpkLaporan $laporan, array $data): void` |
| 1.1j | `Actions/Media/ManageFotosAction.php` | `OpkMediaService` + `LaporanService::uploadFotos()` | `upload(OpkLaporan $laporan, array $files, array $options): void`, `delete(int $laporanId, array $ids): void`, `setUtama(int $laporanId, int $fotoId): void` — **unified photo logic**, context-aware (admin vs public) |
| 1.1k | `Actions/Media/ManageDokumenAction.php` | `LaporanService::uploadDokumen()` | `upload(OpkLaporan $laporan, UploadedFile $file): void` |
| 1.1l | `Actions/Media/SaveVideoLinkAction.php` | `LaporanService::saveVideoLink()` | `execute(OpkLaporan $laporan, ?string $url): void` |
| 1.1m | `Actions/User/CreateUserAction.php` | `PenggunaController::store()` | `execute(array $validated): User` |
| 1.1n | `Actions/User/UpdateUserAction.php` | `PenggunaController::update()` | `execute(User $user, array $validated): User` |
| 1.1o | `Actions/User/ToggleUserActiveAction.php` | `PenggunaController::toggleAktif()` | `execute(User $user): User` |
| 1.1p | `Actions/User/DeleteUserAction.php` | `PenggunaController::destroy()` | `execute(User $user): void` |
| 1.1q | `Actions/Wilayah/ManageKecamatanAction.php` | `KecamatanController` | `create(array $data): Kecamatan`, `update(Kecamatan $kecamatan, array $data): Kecamatan`, `delete(Kecamatan $kecamatan): void` |
| 1.1r | `Actions/Wilayah/ManageDesaDinasAction.php` | `DesaDinasController` | CRUD methods |
| 1.1s | `Actions/Wilayah/ManageDesaAdatAction.php` | `DesaAdatController` | CRUD methods |
| 1.1t | `Actions/Kategori/ManageKategoriAction.php` | `KategoriController` | `create(array $data): OpkCategory`, `update(OpkCategory $kategori, array $data): OpkCategory`, `delete(OpkCategory $kategori): void` (dengan guard: cek `laporans()->count()`) |
| 1.1u | `Actions/Ai/RingkasanEksekutifAction.php` | `AiController::ringkasanEksekutif()` | `execute(): string` — cache check → AI generate → cache store → return |
| 1.1v | `Actions/Ai/ReAnalisisAction.php` | `AiController::reAnalisis()` | `execute(OpkLaporan $laporan): void` — reset AI fields + dispatch AnalisisOpkJob |
| 1.1w | `Actions/Export/ExportCsvAction.php` | `LaporanAdminController::exportCsv()` | `execute(): StreamedResponse` — 67-line CSV logic |

### 1.2 — Unify Photo Upload Logic

**Masalah**: `LaporanService::uploadFotos()` (public, foto pertama jadi utama) dan `OpkMediaService::uploadFotos()` (admin, enforcement 10 foto, lanjut urutan) 80% duplikat.

#### Solusi di `Actions/Media/ManageFotosAction.php`

Satu method `upload()` yang menerima context:

```php
public function upload(OpkLaporan $laporan, array $files, array $options = []): void
{
    $isAdmin = $options['is_admin'] ?? false;
    $keteranganUtama = $options['keterangan_utama'] ?? null;
    $deletedCount = $options['deleted_count'] ?? 0;

    if ($isAdmin) {
        $existingCount = $laporan->fotos()->count();
        if (($existingCount - $deletedCount + count($files)) > 10) {
            throw new \RuntimeException('Total foto maksimal 10.');
        }
    }

    $maxUrutan = $laporan->fotos()->max('urutan') ?? -1;

    foreach ($files as $index => $file) {
        // upload logic...
        $isUtama = ! $isAdmin && $index === 0 && ! $laporan->fotoUtama;
        // ...
    }
}
```

#### Double Check 1.2

```bash
# Pastikan tidak ada duplikasi upload logic
diff <(grep -n "storeAs\|uuid()\|foto_opk" app/Services/LaporanService.php) <(grep -n "storeAs\|uuid()\|foto_opk" app/Services/OpkMediaService.php)
# Setelah unify, salah satu service harus kehilangan logic upload

php artisan test --filter=LaporanServiceTest
php artisan test --filter=OpkMediaServiceTest
```

---

### Double Check — Phase 1

```bash
# 1. Pastikan semua Action class ada
ls app/Actions/Opk/
ls app/Actions/Media/
ls app/Actions/User/
ls app/Actions/Wilayah/
ls app/Actions/Kategori/
ls app/Actions/Ai/
ls app/Actions/Export/

# 2. Run full test suite
php artisan test

# 3. Pastikan tidak ada Action yang menerima Request object
grep -rn "Request" app/Actions/

# 4. Pastikan tidak ada Action yang pakai facade Cache/Http langsung
grep -rn "Cache::\|Http::" app/Actions/
```

---

### CHANGELOG — PHASE 1

```
## Phase 1 — Action Classes — YYYY-MM-DD

### Added
- 23 Action classes: CreateLaporan, SubmitLaporan, UpdateOpk, SoftDeleteOpk, RestoreOpk,
  ForceDeleteOpk, SetujuiLaporan, TolakLaporan, UpdateAiScore, ManageFotos, ManageDokumen,
  SaveVideoLink, CreateUser, UpdateUser, ToggleUserActive, DeleteUser, ManageKecamatan,
  ManageDesaDinas, ManageDesaAdat, ManageKategori, RingkasanEksekutif, ReAnalisis, ExportCsv

### Changed
- Unified photo upload logic: ManageFotosAction handles both admin and public context

### Deprecated
- LaporanService::uploadFotos() → logic moved to ManageFotosAction
- OpkMediaService::uploadFotos() → logic moved to ManageFotosAction
```

---

## PHASE 2 — THIN CONTROLLERS

**Tujuan**: Setiap controller ≤30 lines, hanya orchestration. Semua business logic di Actions, semua data access di Repositories, semua validation di FormRequests.

### 2.1 — Refactor Controllers

Untuk setiap controller, lakukan:
1. Inject Action class(es) + Repository class(es) via constructor
2. Ganti inline Eloquent query → panggil Repository method
3. Ganti business logic → panggil Action method
4. Ganti `$request->validate()` → buat FormRequest class
5. Hapus `Cache::` calls — cache management di Service/Action layer

#### 2.1a — `DashboardPublikController`

Dependencies baru:
```php
public function __construct(
    private OpkStatsService $stats,
    private PetaDataService $peta,
    private OpkLaporanRepository $laporanRepo,
    private OpkCategoryRepository $kategoriRepo,
    private KecamatanRepository $kecamatanRepo,
) {}
```

| Method | Sebelum (line count) | Sesudah (perubahan) |
|--------|---------------------|---------------------|
| `index()` | ~15 lines | Panggil `$this->stats->dashboardPublik()`, `$this->kategoriRepo->getWithOpkCount()`, `$this->kecamatanRepo->getWithOpkCount()`, `$this->laporanRepo->getLatestDisetujui(6)` |
| `petaJson()` | ~5 lines | Delegate ke `$this->peta->getPetaData()` |
| `showOpk()` | ~9 lines | Gunakan `$this->laporanRepo->findWithRelations($opk->id)` lalu cek status |
| `suggestOpk()` | ~25 lines | `$this->laporanRepo->suggest($query)` |
| `daftarOpk()` | ~43 lines | `$this->laporanRepo->getDisetujui($filters)`, `$this->kategoriRepo->getWithOpkCount()`, `$this->kecamatanRepo->getWithOpkCount()` |

#### 2.1b — `LaporController`

Dependencies baru:
```php
public function __construct(
    private CreateLaporanAction $createLaporan,
    private SubmitLaporanAction $submitLaporan,
    private OpkLaporanRepository $laporanRepo,
    private DesaDinasRepository $desaDinasRepo,
    private DesaAdatRepository $desaAdatRepo,
    private OpkCategoryRepository $kategoriRepo,
    private KecamatanRepository $kecamatanRepo,
) {}
```

| Method | Perubahan |
|--------|----------|
| `index()` | `$this->kategoriRepo->getAll()`, `$this->kecamatanRepo->getAll()` |
| `store(StoreLaporanRequest $request)` | `$laporan = $this->createLaporan->execute($request->validated())` → `$this->submitLaporan->execute($laporan)` → redirect. ~5 lines. |
| `getDesaDinas()` | `$this->desaDinasRepo->getByKecamatan($kecamatanId)` |
| `getDesaAdat()` | `$this->desaAdatRepo->getByKecamatan($kecamatanId)` |
| `sukses()` | `$this->laporanRepo->findByKode($kode)` |
| `cekStatus()` | `$this->laporanRepo->findByKode($kode)` |

#### 2.1c — `OpkController`

Dependencies baru:
```php
public function __construct(
    private PetaDataService $peta,
    private OpkMediaService $mediaService,
    private OpkLaporanRepository $laporanRepo,
    private OpkCategoryRepository $kategoriRepo,
    private KecamatanRepository $kecamatanRepo,
    private UpdateOpkAction $updateOpk,
    private SoftDeleteOpkAction $softDeleteOpk,
    private RestoreOpkAction $restoreOpk,
    private ForceDeleteOpkAction $forceDeleteOpk,
) {}
```

| Method | Perubahan |
|--------|----------|
| `index()` | `$this->laporanRepo->getDisetujui($filters)`, kategori/kecamatan dari repo |
| `show()` | `$this->laporanRepo->findWithRelations($laporan->id)` |
| `edit()` | `$this->laporanRepo->findWithRelations($laporan->id)` (atau pakai implicit binding) |
| `update(UpdateOpkRequest $request, OpkLaporan $laporan)` | `$this->updateOpk->execute($laporan, $request->validated())` |
| `destroy(OpkLaporan $laporan)` | `$this->softDeleteOpk->execute($laporan)` |
| `restore($id)` | `$this->restoreOpk->execute($id)` |
| `forceDelete($id)` | `$this->forceDeleteOpk->execute($id)` |
| `arsip()` | `$this->laporanRepo->getArsip()` |
| `peta()` | return view |
| `petaJson()` | `$this->peta->getPetaData($request, true)` |

#### 2.1d — `VerifikasiController`

Dependencies baru:
```php
public function __construct(
    private OpkLaporanRepository $laporanRepo,
    private SetujuiLaporanAction $setujui,
    private TolakLaporanAction $tolak,
    private UpdateAiScoreAction $updateAiScore,
) {}
```

| Method | Perubahan |
|--------|----------|
| `index()` | `$this->laporanRepo->getMenunggu($filters)` |
| `show()` | `$this->laporanRepo->findWithRelations($laporan->id)` |
| `setujui(VerifikasiRequest $request, OpkLaporan $laporan)` | `$this->setujui->execute($laporan, auth()->user(), $request->catatan)` |
| `tolak(VerifikasiRequest $request, OpkLaporan $laporan)` | `$this->tolak->execute($laporan, auth()->user(), $request->alasan, $request->catatan)` |
| `updateAiScore(Request $request, OpkLaporan $laporan)` | `$this->updateAiScore->execute($laporan, $request->validated())` |

#### 2.1e — `PenggunaController`

Dependencies baru:
```php
public function __construct(
    private UserRepository $userRepo,
    private CreateUserAction $createUser,
    private UpdateUserAction $updateUser,
    private ToggleUserActiveAction $toggleUser,
    private DeleteUserAction $deleteUser,
) {}
```

#### 2.1f — `KecamatanController`, `DesaDinasController`, `DesaAdatController`

Dependencies baru via Actions (lihat 1.1q, 1.1r, 1.1s).

#### 2.1g — `KategoriController`

Dependencies baru:
```php
public function __construct(
    private OpkCategoryRepository $kategoriRepo,
    private ManageKategoriAction $manageKategori,
) {}
```

#### 2.1h — `LaporanAdminController`

Dependencies baru:
```php
public function __construct(
    private OpkStatsService $stats,
    private ExportCsvAction $exportCsv,
) {}
```

#### 2.1i — `AiController`

Dependencies baru:
```php
public function __construct(
    private AiOpkAnalyzer $ai,
    private RingkasanEksekutifAction $ringkasan,
    private ReAnalisisAction $reAnalisis,
) {}
```

#### 2.1j — `DashboardController`

Dependencies baru:
```php
public function __construct(
    private OpkStatsService $stats,
    private OpkLaporanRepository $laporanRepo,
) {}
```

### 2.2 — Create FormRequests untuk Write Methods yang Belum Punya

Buat FormRequest class (bukan inline `$request->validate()`) untuk:

| FormRequest | Untuk Controller/Method |
|------------|------------------------|
| `VerifikasiRequest` | `VerifikasiController::setujui()`, `tolak()` |
| `UpdateAiScoreRequest` | `VerifikasiController::updateAiScore()` |
| `KecamatanRequest` | `KecamatanController::store()`, `update()` |
| `DesaDinasRequest` | `DesaDinasController::store()`, `update()` |
| `DesaAdatRequest` | `DesaAdatController::store()`, `update()` |
| `KategoriRequest` | `KategoriController::store()`, `update()` |
| `ChatAiRequest` | `AiController::chat()` |
| `KlasifikasiRequest` | `AiController::klasifikasi()` |

Setiap FormRequest:
- `authorize()` → panggil Policy method yang sesuai, atau return true jika di-handle middleware
- `rules()` → pindahkan dari controller

### 2.3 — Update AppServiceProvider

Register semua Action classes di `AppServiceProvider::register()`:

```php
// Action classes
$this->app->singleton(CreateLaporanAction::class);
$this->app->singleton(SubmitLaporanAction::class);
$this->app->singleton(UpdateOpkAction::class);
// ... all 23 actions
```

### Double Check — Phase 2

```bash
# 1. Cek tidak ada Eloquent query di controller
grep -rn "::where\|::find\|::create\|::with\|::select\|::orderBy\|::paginate\|::get()\|::first()\|DB::raw\|DB::table" app/Http/Controllers/ | grep -v "Repository"

# 2. Cek tidak ada $request->validate() di controller (semua harus FormRequest)
grep -rn '\$request->validate\|\$this->validate' app/Http/Controllers/

# 3. Cek tidak ada Cache:: di controller
grep -rn "Cache::" app/Http/Controllers/

# 4. Cek tidak ada DB::transaction di controller
grep -rn "DB::transaction\|DB::beginTransaction" app/Http/Controllers/

# 5. Tidak boleh ada controller > 50 lines
find app/Http/Controllers -name "*.php" -exec wc -l {} \; | awk '$1 > 50 {print $0}'

# 6. Run tests
php artisan test

# 7. Route list tetap sama
php artisan route:list
```

---

### CHANGELOG — PHASE 2

```
## Phase 2 — Thin Controllers — YYYY-MM-DD

### Changed
- 13 controllers refactored: all inject Actions + Repositories
- All controllers ≤40 lines (target ≤30)
- All write operations use FormRequests (8 new FormRequest classes)

### Added
- 8 FormRequest classes: VerifikasiRequest, UpdateAiScoreRequest, KecamatanRequest,
  DesaDinasRequest, DesaAdatRequest, KategoriRequest, ChatAiRequest, KlasifikasiRequest
- Action class registrations in AppServiceProvider

### Removed
- All inline $request->validate() from controllers
- All inline Eloquent queries from controllers
- All Cache:: calls from controllers
- All DB::transaction calls from controllers
```

---

## PHASE 3 — SERVICE CLEANUP

**Tujuan**: Remove duplication, fix contracts, reduce coupling.

### 3.1 — Merge LaporanService → OpkMediaService + Actions

Setelah Phase 1, photo upload logic sudah di `ManageFotosAction`. Sekarang bersihkan `LaporanService`:

1. **Hapus** dari `LaporanService`: `uploadFotos()`, `uploadDokumen()`, `saveVideoLink()` — sudah di Action.
2. **Pertahankan** di `LaporanService`: `createLaporan()` — ini tetap sebagai domain service untuk membuat record OpkLaporan.
3. **Hapus** dari `OpkMediaService`: `uploadFotos()` — sudah di Action.
4. **Pertahankan** di `OpkMediaService`: `deleteFotos()`, `setFotoUtama()` — atau pindahkan juga ke Action.

### 3.2 — Extract PetaDataService Static Coupling

`VerifikasiService` line 53: `PetaDataService::invalidateCache();` — static call.

Ganti dengan event-driven: `VerifikasiService` dispatch event, listener clears cache.

Atau: inject `PetaDataService` ke `VerifikasiService` (non-static). Pilih opsi yang paling sederhana: **jadikan instance method call**.

```php
// VerifikasiService
public function __construct(private PetaDataService $petaService) {}

// Di updateStatus, setelah DB::commit():
$this->petaService->invalidateCache();
```

Hapus keyword `static` dari `PetaDataService::invalidateCache()`.

### 3.3 — De-duplicate OpkStatsService

3 method overlap (`dashboardAdmin`, `laporanAdmin`, `ringkasanEksekutif`). Extract private builder:

```php
private function baseQuery(): \Illuminate\Database\Query\Builder
{
    return DB::table('opk_laporans')->whereNull('deleted_at');
}

private function countByStatus(string $status): int
{
    return $this->baseQuery()->where('status_verifikasi', $status)->count();
}
```

### 3.4 — WhatsAppService Config

Pindahkan hardcoded URL dari `WhatsAppService::send()` ke `config/services.php`:

```php
// config/services.php
'whatsapp' => [
    'token' => env('FONNTE_TOKEN'),
    'api_url' => env('FONNTE_API_URL', 'https://api.fonnte.com/send'),
    'country_code' => env('FONNTE_COUNTRY_CODE', '62'),
    'admin_wa' => env('FONNTE_ADMIN_WA'),
    'timeout' => 15,
    'connect_timeout' => 5,
],
```

### Double Check — Phase 3

```bash
# 1. Cek tidak ada static method call lintas service
grep -rn "::invalidateCache\|::static" app/Services/

# 2. Cek tidak ada hardcoded URL di service
grep -rn "https://" app/Services/

# 3. Run tests
php artisan test
```

---

### CHANGELOG — PHASE 3

```
## Phase 3 — Service Cleanup — YYYY-MM-DD

### Changed
- LaporanService: removed uploadFotos/uploadDokumen/saveVideoLink (→ Actions)
- OpkMediaService: removed uploadFotos (→ Actions)
- PetaDataService::invalidateCache() → instance method (was static)
- OpkStatsService: extracted shared query builders
- WhatsAppService: API URL moved to config/services.php

### Fixed
- Cross-service static coupling (PetaDataService)
```

---

## PHASE 4 — EVENTS/JOBS HARDENING

**Tujuan**: Fix critical bugs yang ditemukan audit.

### 4.1 — Fix AnalisisOpkJob Exception Swallowing

**File**: `app/Jobs/AnalisisOpkJob.php`

**Masalah**: `catch (\Exception $e)` di line 82 menelan exception → job tidak retry walaupun `$tries = 3`.

**Fix**:

```php
// HAPUS try-catch di dalam handle()
// Biarkan exception propagate. failed() method sudah ada untuk handle fallback.

public function handle(AiOpkAnalyzer $ai): void
{
    $laporan = OpkLaporan::with(['kategori', 'kecamatan'])->find($this->laporanId);

    if (! $laporan) {
        Log::warning("AnalisisOpkJob: laporan ID {$this->laporanId} tidak ditemukan.");
        return;
    }

    $laporan->update(['status_verifikasi' => StatusVerifikasi::AiReview->value]);

    Log::info("AI mulai analisis laporan: {$laporan->kode_laporan}");

    $hasil = $ai->analisisLaporan($laporan);

    $laporan->update([
        'ai_urgency_score' => $hasil['urgency_score'],
        'ai_duplikat_score' => $hasil['duplikat_score'],
        'ai_duplikat_of' => $hasil['duplikat_id'],
        'ai_rekomendasi' => $this->formatRekomendasi($hasil),
        'status_verifikasi' => StatusVerifikasi::ReviewDinas->value,
    ]);

    OpkRiwayatStatus::create([
        'laporan_id' => $laporan->id,
        'status_lama' => StatusVerifikasi::AiReview->value,
        'status_baru' => StatusVerifikasi::ReviewDinas->value,
        'catatan' => sprintf(
            'AI Score: %.1f/10 | Duplikat: %.0f%% | %s',
            $hasil['urgency_score'],
            $hasil['duplikat_score'],
            $hasil['rekomendasi']
        ),
    ]);

    Log::info("AI selesai: {$laporan->kode_laporan} | Score: {$hasil['urgency_score']}");

    AiAnalysisCompleted::dispatch($laporan);
}
```

### 4.2 — Add ShouldBeUnique to AnalisisOpkJob

```php
use Illuminate\Contracts\Queue\ShouldBeUnique;

class AnalisisOpkJob implements ShouldQueue, ShouldBeUnique
{
    // ...

    public function uniqueId(): string
    {
        return 'analisis-opk-'.$this->laporanId;
    }
}
```

### 4.3 — Add ShouldBeUnique to SendWhatsAppNotifJob

```php
use Illuminate\Contracts\Queue\ShouldBeUnique;

class SendWhatsAppNotifJob implements ShouldQueue, ShouldBeUnique
{
    // ...

    public function uniqueId(): string
    {
        return "wa-{$this->action}-{$this->kodeLaporan}";
    }
}
```

### 4.4 — Fix Event Dispatch Inside Transaction

**File**: `app/Services/VerifikasiService.php`

Event `LaporanVerified::dispatch()` di-dispatch di DALAM transaction (line 52). Jika listener gagal, transaction rollback tapi event sudah dikirim.

SOLUSI A — dispatch after commit:

```php
DB::commit();

// Dispatch after commit — jika ini gagal, transaction tetap committed (yang kita inginkan)
event(new LaporanVerified($laporan, $statusBaru));
$this->petaService->invalidateCache();
```

Atau SOLUSI B — gunakan `ShouldDispatchAfterCommit` di Listener:

```php
// SideEffectHandler
class SideEffectHandler implements ShouldDispatchAfterCommit
```

**Pilih SOLUSI A** — paling sederhana, tidak ada side effect di dalam transaction.

### 4.5 — Log Level + PII Cleanup

| File | Line | Saat ini | Ganti |
|------|------|---------|-------|
| `SideEffectHandler.php` | 25 | `Log::warning(... {$event->laporan->pelapor_whatsapp})` | `Log::info(... [REDACTED])` — jangan log nomor WA |
| `SendWhatsAppNotifJob.php` | 31 | `Log::warning("SendWhatsAppNotifJob...")` | `Log::info(...)` — ini normal operation, bukan warning |
| `FonnteWebhookController.php` | 39 | `Log::info(... full payload)` | Hapus logging payload, atau redact PII |

### 4.6 — Fix FonnteHealthCheck Exit Code

**File**: `app/Console/Commands/FonnteHealthCheck.php`

```php
// Ganti return self::SUCCESS di akhir jadi:
return $deviceOk ? self::SUCCESS : self::FAILURE;
```

### Double Check — Phase 4

```bash
# 1. Cek tidak ada exception swallowing di job
grep -A5 "catch.*Exception" app/Jobs/

# 2. Cek ShouldBeUnique implementation
grep "ShouldBeUnique" app/Jobs/AnalisisOpkJob.php
grep "ShouldBeUnique" app/Jobs/SendWhatsAppNotifJob.php
grep "uniqueId" app/Jobs/AnalisisOpkJob.php
grep "uniqueId" app/Jobs/SendWhatsAppNotifJob.php

# 3. Cek tidak ada event dispatch di dalam transaction
grep -B10 "dispatch\|event(" app/Services/VerifikasiService.php | grep -A2 "DB::commit"

# 4. Cek tidak ada PII di log
grep -rn "pelapor_whatsapp\|pelapor_nik\|nomorWa" app/Listeners/
grep -rn "pelapor_whatsapp\|pelapor_nik" app/Jobs/

# 5. Run tests
php artisan test
```

---

### CHANGELOG — PHASE 4

```
## Phase 4 — Events/Jobs Hardening — YYYY-MM-DD

### Fixed
- AnalisisOpkJob: removed exception swallowing → job correctly retries on failure
- AnalisisOpkJob: added ShouldBeUnique to prevent duplicate analysis
- SendWhatsAppNotifJob: added ShouldBeUnique to prevent duplicate WhatsApp messages
- VerifikasiService: event dispatch moved after DB::commit()
- Log levels normalized: warning → info for normal business events
- PII (WhatsApp numbers) removed from log output
- FonnteHealthCheck: returns FAILURE exit code when device disconnected
```

---

## PHASE 5 — VIEWS & COMPONENTS

**Tujuan**: Extract sidebar component, clean unused files.

### 5.1 — Extract Sidebar Component

**Sumber**: `resources/views/layouts/app.blade.php` lines 25-98

**Target**: `resources/views/components/layouts/sidebar.blade.php`

Pindahkan seluruh sidebar markup + JavaScript toggle logic ke component file. Props:
- `$sidebarAntrian` (from SidebarComposer)
- `$sidebarAiKritis` (from SidebarComposer)

Include di layout: `<x-layouts.sidebar :antrian="$sidebarAntrian" :aiKritis="$sidebarAiKritis" />`

### 5.2 — Clean Dead Components

| File/Dir | Action |
|----------|--------|
| `components/info-row.blade.php` | Hapus (superseded by `x-ui.info-rows`) |
| `components/admin/` (empty dir) | Hapus |
| `components/opk/` (empty dir) | Hapus |
| `components/verifikasi/` (empty dir) | Hapus |
| `components/publik/` (empty dir) | Hapus |
| `resources/views/welcome.blade.php` | Hapus (Laravel default, tidak dipakai) |

### Double Check — Phase 5

```bash
# 1. Pastikan sidebar component ada dan dipanggil
grep "x-layouts.sidebar" resources/views/layouts/app.blade.php

# 2. Pastikan dead components sudah dihapus
ls resources/views/components/info-row.blade.php 2>&1 | grep "No such file"
ls resources/views/components/admin/ 2>&1 | grep "No such file"

# 3. Tidak ada referensi ke file yang dihapus
grep -rn "info-row" resources/views/ routes/ app/
grep -rn "welcome" resources/views/ routes/ app/ | grep -v "vendor"

# 4. Run tests
php artisan test
```

---

### CHANGELOG — PHASE 5

```
## Phase 5 — Views & Components — YYYY-MM-DD

### Changed
- Sidebar extracted from layouts/app.blade.php → components/layouts/sidebar.blade.php

### Removed
- components/info-row.blade.php (superseded by x-ui.info-rows)
- 4 empty component directories (admin, opk, verifikasi, publik)
- welcome.blade.php (unused Laravel default)
```

---

## PHASE 6 — TEST COVERAGE

**Tujuan**: Isi gap coverage yang ditemukan audit.

### 6.1 — Model Factories

Buat factory untuk model yang belum punya:

```bash
php artisan make:factory OpkLaporanFactory --model=OpkLaporan
php artisan make:factory OpkCategoryFactory --model=OpkCategory
php artisan make:factory KecamatanFactory --model=Kecamatan
php artisan make:factory DesaDinasFactory --model=DesaDinas
php artisan make:factory DesaAdatFactory --model=DesaAdat
```

### 6.2 — Unit Tests: Actions

Setiap Action class wajib punya minimal 1 test:

| Test File | Action yang di-test |
|-----------|-------------------|
| `tests/Unit/Actions/CreateLaporanActionTest.php` | `CreateLaporanAction` |
| `tests/Unit/Actions/SetujuiLaporanActionTest.php` | `SetujuiLaporanAction` |
| `tests/Unit/Actions/TolakLaporanActionTest.php` | `TolakLaporanAction` |
| `tests/Unit/Actions/CreateUserActionTest.php` | `CreateUserAction` |
| `tests/Unit/Actions/UpdateUserActionTest.php` | `UpdateUserAction` |
| `tests/Unit/Actions/ToggleUserActiveActionTest.php` | `ToggleUserActiveAction` |
| `tests/Unit/Actions/ManageFotosActionTest.php` | `ManageFotosAction` |

### 6.3 — Unit Tests: Repositories

| Test File | Repository yang di-test |
|-----------|------------------------|
| `tests/Unit/Repositories/OpkLaporanRepositoryTest.php` | `OpkLaporanRepository` |
| `tests/Unit/Repositories/KecamatanRepositoryTest.php` | `KecamatanRepository` |

### 6.4 — Unit Tests: Jobs

| Test File | Job yang di-test |
|-----------|-----------------|
| `tests/Unit/Jobs/AnalisisOpkJobTest.php` | `AnalisisOpkJob` |
| `tests/Unit/Jobs/SendWhatsAppNotifJobTest.php` | `SendWhatsAppNotifJob` |

### 6.5 — Unit Tests: Events & Listeners

| Test File | Yang di-test |
|-----------|-------------|
| `tests/Unit/Listeners/SideEffectHandlerTest.php` | `SideEffectHandler` — verify cache clearing + WhatsApp job dispatch |

### 6.6 — Unit Tests: AI Providers

| Test File | Yang di-test |
|-----------|-------------|
| `tests/Unit/Ai/AiProviderFactoryTest.php` | `AiProviderFactory` |
| `tests/Unit/Ai/AiOpkAnalyzerTest.php` | `AiOpkAnalyzer` |

### 6.7 — Unit Tests: Policies

| Test File | Yang di-test |
|-----------|-------------|
| `tests/Unit/Policies/OpkLaporanPolicyTest.php` | `OpkLaporanPolicy` |
| `tests/Unit/Policies/UserPolicyTest.php` | `UserPolicy` |

### 6.8 — Unit Tests: Console Commands

| Test File | Command |
|-----------|---------|
| `tests/Unit/Commands/AnalisisSemuaOpkCommandTest.php` | `siopk:analisis-semua` |
| `tests/Unit/Commands/FonnteHealthCheckTest.php` | `siopk:fonnte-check` |

### Double Check — Phase 6

```bash
# 1. Run full test suite
php artisan test

# 2. Test coverage report (jika XDebug tersedia)
php artisan test --coverage

# 3. Cek semua Action punya test
for f in app/Actions/**/*.php app/Actions/*.php; do
  name=$(basename "$f" .php)
  grep -rn "$name" tests/ > /dev/null || echo "MISSING TEST: $name"
done
```

---

### CHANGELOG — PHASE 6

```
## Phase 6 — Test Coverage — YYYY-MM-DD

### Added
- 5 Model factories (OpkLaporan, OpkCategory, Kecamatan, DesaDinas, DesaAdat)
- 7 Action unit tests
- 2 Repository unit tests
- 2 Job unit tests
- 1 Listener unit test
- 2 AI unit tests
- 2 Policy unit tests
- 2 Console command unit tests
```

---

## APPENDIX A — File Dependency Map

```
Controllers (inject) → Actions + Repositories
Actions (call)       → Services + Repositories + Events
Services (use)       → Repositories + Models
Repositories (query) → Models
Jobs (call)          → Services + Repositories
Events (carry)       → Models
Listeners (handle)   → Cache + Jobs
```

## APPENDIX B — Verifikasi Quick Check Per Phase

Jalankan command ini setelah **setiap phase selesai**:

```bash
# Phase 0
php artisan test && echo "PHASE 0 OK" || echo "PHASE 0 FAIL"

# Phase 1
php artisan test && ls app/Actions/*/ | wc -l && echo "PHASE 1 OK" || echo "PHASE 1 FAIL"

# Phase 2
php artisan test && \
  [ $(grep -rn "::where\|::find\|DB::raw" app/Http/Controllers/ | wc -l) -eq 0 ] && \
  echo "PHASE 2 OK" || echo "PHASE 2 FAIL"

# Phase 3
php artisan test && echo "PHASE 3 OK" || echo "PHASE 3 FAIL"

# Phase 4
php artisan test && \
  [ $(grep -A5 "catch.*Exception" app/Jobs/AnalisisOpkJob.php | wc -l) -eq 0 ] && \
  echo "PHASE 4 OK" || echo "PHASE 4 FAIL"

# Phase 5
php artisan test && echo "PHASE 5 OK" || echo "PHASE 5 FAIL"

# Phase 6
php artisan test && echo "PHASE 6 OK" || echo "PHASE 6 FAIL"
```

## APPENDIX C — Rollback Strategy

Jika suatu phase menyebabkan regression:

1. **Jangan lanjut ke phase berikutnya** — fix regression dulu.
2. Kalau perlu rollback: `git stash` atau `git checkout -- .` untuk file phase tersebut.
3. Run `php artisan test` untuk konfirmasi rollback bersih.
4. Catat issue yang ditemukan, fix, lalu ulangi phase.

---

**Dokumen ini adalah single source of truth untuk rewrite. Jangan membuat keputusan arsitektural di luar yang tertulis di sini tanpa konfirmasi.**
