# PRD — Product Requirements Document

## SIOPK Badung — Sistem Informasi Objek Pemajuan Kebudayaan Kabupaten Badung

**Versi**: 1.0  
**Tanggal**: Juni 2026  
**Status**: MVP selesai (Fase 1–6), Fase 7 dalam pengembangan

---

## 1. Executive Summary

SIOPK Badung adalah platform digital berbasis web untuk pemetaan partisipatif 10 Objek Pemajuan Kebudayaan (OPK) di Kabupaten Badung, Bali. Sistem memungkinkan masyarakat melaporkan warisan budaya, Dinas Kebudayaan melakukan verifikasi berbantuan AI, dan pimpinan daerah memantau kondisi OPK melalui dashboard eksekutif dengan WebGIS.

### 1.1 Visi Produk

Menjadi sistem informasi terpadu untuk inventarisasi, pemantauan, dan pelestarian warisan budaya Kabupaten Badung yang melibatkan partisipasi masyarakat.

### 1.2 Target Pengguna

| Persona | Deskripsi | Kebutuhan Utama |
|---------|-----------|-----------------|
| **Masyarakat / Tokoh Adat** | Warga Badung yang mengetahui objek budaya di desanya | Melaporkan OPK dengan mudah via web, memantau status laporan |
| **Verifikator Dinas** | Petugas Dinas Kebudayaan yang memvalidasi laporan | Antrian verifikasi, panduan AI, approve/reject |
| **Admin Dinas** | Administrator sistem di Dinas Kebudayaan | Kelola data OPK, pengguna, statistik, ekspor |
| **Kepala Dinas / Bupati** | Pengambil keputusan tingkat kabupaten | Ringkasan eksekutif, peta sebaran OPK, prioritas pemeliharaan |
| **Petugas Lapangan** | Petugas yang melakukan kunjungan fisik ke lokasi OPK | Data OPK terverifikasi, koordinat GPS, foto dokumentasi |

### 1.3 Success Metrics

| Metrik | Target (6 bulan) | Target (2 tahun) |
|--------|-----------------|-----------------|
| Laporan OPK terkumpul | 200+ | 2.000+ |
| Laporan disetujui (masuk peta) | 80% dari total | 90% dari total |
| Kecamatan terdokumentasi | 6/6 kecamatan | 6/6 + seluruh desa adat |
| Waktu verifikasi rata-rata | < 3 hari | < 1 hari |
| Skor akurasi AI klasifikasi | > 70% | > 90% |
| Kepuasan pengguna | > 3.5/5 | > 4.0/5 |

---

## 2. Product Features

### 2.1 MVP (Fase 1–6) — ✅ Selesai

| ID | Fitur | Deskripsi | Prioritas |
|----|-------|-----------|-----------|
| F-01 | Form laporan publik 5 langkah | Multi-step form: identitas OPK → lokasi GPS → deskripsi budaya → media upload → data pelapor | P0 |
| F-02 | Validasi laporan | Validasi server-side via Form Request, pesan error Bahasa Indonesia | P0 |
| F-03 | Upload multi-foto | Maksimal 10 foto per laporan, format JPG/PNG, satu foto utama | P0 |
| F-04 | Peta publik interaktif | WebGIS Leaflet + OpenStreetMap, filter kondisi/kategori/kecamatan, detail popup | P0 |
| F-05 | Autentikasi & RBAC | Login/logout, 5 role (superadmin, admin, verifikator, petugas, publik), rate limit | P0 |
| F-06 | Panel verifikasi | Antrian laporan, approve/reject, catatan verifikasi, riwayat status | P0 |
| F-07 | Analisis AI otomatis | Urgency score, deteksi duplikat, rekomendasi tindakan, auto-klasifikasi | P1 |
| F-08 | Dashboard eksekutif | KPI cards, peta admin, prioritas pemeliharaan, statistik per kategori/kecamatan | P1 |
| F-09 | Chat asisten AI | Tanya-jawab kontekstual tentang laporan spesifik untuk verifikator | P2 |
| F-10 | Ringkasan eksekutif AI | Laporan mingguan otomatis untuk kepala dinas, cache 6 jam | P2 |
| F-11 | Cek status laporan | Publik bisa cek status laporan via kode unik | P1 |
| F-12 | Ekspor CSV | Streaming export untuk semua data OPK terverifikasi | P2 |
| F-13 | Manajemen pengguna | CRUD user, aktivasi/nonaktif, role assignment | P1 |
| F-14 | Arsip OPK | Soft delete + restore, force delete permanen + file cleanup | P2 |
| F-15 | Multi-provider AI | Claude, OpenAI, DeepSeek, Groq, Custom — switch via `.env` | P1 |

### 2.2 Fase 7 — 🔜 Dalam Pengembangan

| ID | Fitur | Deskripsi | Prioritas |
|----|-------|-----------|-----------|
| F-16 | Notifikasi WhatsApp | Auto-notif ke pelapor saat laporan disetujui/ditolak | P1 |
| F-17 | Dashboard Chart.js | Visualisasi chart interaktif (pie, bar, line, radar) | P2 |
| F-18 | Photo gallery lightbox | Tampilan galeri foto dengan zoom, swipe, fullscreen | P2 |

### 2.3 Backlog — Future

| ID | Fitur | Deskripsi | Prioritas |
|----|-------|-----------|-----------|
| F-19 | REST API + Sanctum | Token-based auth untuk mobile app / integrasi eksternal | P3 |
| F-20 | Mobile app (Flutter) | Aplikasi mobile untuk petugas lapangan (offline-capable) | P3 |
| F-21 | Multi-kabupaten | Scale ke 9 kabupaten/kota Bali dengan RBAC per wilayah | P3 |
| F-22 | QR Code pada papan informasi OPK | QR code yang mengarah ke halaman detail OPK | P3 |
| F-23 | Versioning data OPK | Riwayat perubahan data OPK (audit trail penuh) | P3 |

---

## 3. Constraints & Assumptions

### 3.1 Constraints

| Constraint | Deskripsi |
|-----------|-----------|
| **Deployment** | XAMPP/Windows (dev) — target produksi: Linux VPS + Docker |
| **Budget** | Nol biaya lisensi — semua stack open-source |
| **Tim** | 1–2 developer part-time (mahasiswa/dosen) |
| **Internet** | Tidak semua desa adat punya akses internet stabil |
| **Regulasi** | UU No. 5 Tahun 2017 tentang Pemajuan Kebudayaan |

### 3.2 Assumptions

- Masyarakat memiliki smartphone dengan kamera dan akses internet minimal
- Dinas Kebudayaan memiliki komputer dengan akses internet untuk verifikasi
- API key Claude/DeepSeek tersedia dan terjangkau
- Data GPS yang dilaporkan masyarakat cukup akurat (±10 meter)
- Kategori OPK mengikuti 10 jenis sesuai UU No.5/2017 dan tidak akan bertambah dalam waktu dekat

---

## 4. Release Plan

| Fase | Fitur Utama | Status | Tanggal Target |
|------|------------|--------|---------------|
| 1 | Setup, database, migrasi, seeder | ✅ Selesai | 2025-01 |
| 2 | Auth & RBAC (5 role) | ✅ Selesai | 2025-01 |
| 3 | Form laporan publik 5 langkah | ✅ Selesai | 2025-02 |
| 4 | Panel verifikasi Dinas | ✅ Selesai | 2025-03 |
| 5 | Dashboard + WebGIS Leaflet | ✅ Selesai | 2025-04 |
| 6 | Integrasi AI (Claude + multi-provider) | ✅ Selesai | 2025-05 |
| 7 | WhatsApp notifikasi + Chart.js | 🔜 In progress | 2026-07 |
| 8 | REST API + Sanctum | 📋 Backlog | Tidak ada rencana |

---

## 5. Stakeholder

| Stakeholder | Peran | Kepentingan |
|------------|-------|------------|
| Dinas Kebudayaan Badung | Product owner | Data OPK akurat, pelestarian budaya |
| Bupati Badung | Sponsor | Laporan eksekutif, kebijakan berbasis data |
| Desa Adat se-Badung | Kontributor data | OPK di desanya terdokumentasi dan dilestarikan |
| Akademisi (Univ terkait) | Tim pengembang | Skripsi/penelitian, publikasi ilmiah |
| Masyarakat umum | Pengguna | Akses informasi budaya, partisipasi pelaporan |
