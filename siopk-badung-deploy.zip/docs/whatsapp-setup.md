# WhatsApp Notification Setup — SIOPK Badung

## Provider: Fonnte (https://fonnte.com)

Fonnte adalah WhatsApp API gateway Indonesia berbasis WhatsApp Web. **Tanpa** verifikasi nomor Meta, tanpa KYC bisnis, tanpa message template approval. Cukup scan QR dan dapatkan token.

### Kelebihan vs Meta Cloud API

- Tidak perlu verifikasi nomor telepon / KYC bisnis
- Tidak perlu bikin message template yang direview Meta
- Free-form messaging — isi pesan bebas
- API simpel — 1 endpoint, token-based auth
- Support Bahasa Indonesia
- Anti-ban: random delay, random device rotation

## 1. Setup Fonnte

### Daftar & Connect Device

1. Buka [md.fonnte.com](https://md.fonnte.com/new/register.php) — daftar akun
2. Login → **Devices** → **Add Device**
3. Scan QR code via WhatsApp di HP: **Settings → Linked Devices → Link a Device**
4. Device muncul di dashboard → **klik device** → copy **Token**

### Paket

| Paket | Harga | Fitur |
|-------|-------|-------|
| Free | Rp 0 | Kirim text, ada branding "Powered by Fonnte" di akhir pesan |
| Regular | Rp 25K/bln | Tanpa branding |
| Super | Rp 75K/bln | + kirim gambar/file |
| Advanced | Rp 150K/bln | + random device |
| Ultra | Rp 300K/bln | + semua fitur, prioritas support |

## 2. Konfigurasi `.env`

```ini
FONNTE_TOKEN=xxxxxxxxxxxxx          # token dari dashboard Fonnte
# FONNTE_COUNTRY_CODE=62            # optional, default 62 (Indonesia)
```

## 3. Jalankan Queue Worker

```bash
# Development (sync, tanpa worker terpisah)
QUEUE_CONNECTION=sync

# Production (perlu worker)
QUEUE_CONNECTION=database
php artisan queue:work --sleep=3 --tries=3 --max-time=3600
```

## 4. Flow Notifikasi

| Event | Trigger | Pesan WA |
|-------|---------|----------|
| Pelapor submit form | `LaporController::store()` | Laporan Diterima + kode laporan |
| Verifikator setujui | `VerifikasiService::setujuiLaporan()` | Laporan Disetujui |
| Verifikator tolak | `VerifikasiService::tolakLaporan()` | Laporan Ditolak + catatan |

Notifikasi dikirim via queue job (`SendWhatsAppNotifJob`) — tidak blocking request cycle.
Job punya retry 2x dengan backoff `[5s, 30s]`.

## 5. Monitoring — Jaga Device Tetap Connected

Device Fonnte bisa disconnect kalau:
- HP mati / tidak ada internet
- WhatsApp di-clear dari recent apps
- WhatsApp auto-update dan linked device reset

### A. Health Check Otomatis (Scheduler)

Sudah terpasang di `routes/console.php` — tiap 15 menit cek status device:

```bash
# Output log di:
storage/logs/fonnte-check.log
```

Kalau device disconnect, muncul di log:

### B. Webhook Device Status

Fonnte akan kirim notifikasi ke endpoint SIOPK saat status device berubah. Setup:

1. Buka **Dashboard Fonnte** → **Devices** → klik device → **Webhook**
2. Isi **Webhook URL**: `https://domain-anda.com/webhook/fonnte/device-status`
3. Centang event **Device Status**
4. Save

| Status | Yang terjadi di SIOPK |
|--------|----------------------|
| `connected` | Log info |
| `disconnected` | Log error + kirim WA alert ke admin (kalau `FONNTE_ADMIN_WA` diisi) |

### C. Alert WA ke Admin

Tambah di `.env`:

```ini
FONNTE_ADMIN_WA=0896xxxxxxxx   # nomor admin yang dapat alert disconnect
```

Saat device disconnect, admin langsung dapat WA: *"ALERT: Device xxx disconnected. Cek segera."*

### D. Cara reconnect

1. Buka dashboard Fonnte → device yang disconnect
2. Klik **Reconnect** → scan QR via WhatsApp → Linked Devices
3. Device langsung connect kembali
4. Pesan yang pending akan otomatis terkirim

## 6. Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Token invalid | Cek token di dashboard Fonnte, pastikan device masih connected (WhatsApp di HP online) |
| Device disconnected | Buka WhatsApp di HP → Linked Devices → pastikan device Fonnte masih terhubung. QR scan ulang jika perlu |
| "Powered by Fonnte" di pesan | Upgrade ke paket Regular (Rp 25K/bln) atau lebih tinggi |
| Pesan tidak terkirim | Cek `storage/logs/laravel.log` — cari "Fonnte notification failed" |
| Nomor tidak valid | Pastikan format nomor WA pelapor benar (08xxx atau 628xxx) |
| Delay antar pesan | Queue worker otomatis handle. Jika perlu delay tambahan, bisa tambah `--sleep=3` di command worker |
