# CONTEXT — Domain Context

## SIOPK Badung — Latar Belakang & Konteks Domain

---

## 1. Latar Belakang Hukum

### 1.1 UU No. 5 Tahun 2017 tentang Pemajuan Kebudayaan

Sistem ini dibangun berdasarkan amanat UU Pemajuan Kebudayaan yang mendefinisikan **10 Objek Pemajuan Kebudayaan (OPK)**:

| No | OPK | Definisi | Contoh di Badung |
|----|-----|----------|-----------------|
| 1 | **Tradisi Lisan** | Tutur, cerita rakyat, pantun, dongeng | Satua Bali, wewangsalan |
| 2 | **Manuskrip** | Lontar, babad, naskah kuno, prasasti | Lontar Usada, Babad Mengwi |
| 3 | **Adat Istiadat** | Hukum adat, tata kelola komunitas, sanksi adat | Awig-awig desa adat |
| 4 | **Ritus** | Upacara keagamaan, ritual siklus hidup, ritual tolak bala | Ngaben, Melasti, Ngurek |
| 5 | **Pengetahuan Tradisional** | Pengobatan tradisional, etnobotani, perbintangan | Usada Bali, pengobatan herbal |
| 6 | **Teknologi Tradisional** | Subak, tenun, arsitektur tradisional, alat pertanian | Subak, arsitektur Bali |
| 7 | **Seni** | Tari, musik, ukir, lukis, pertunjukan, sastra | Tari Kecak, Gong Kebyar, ukiran |
| 8 | **Bahasa** | Bahasa daerah, dialek, aksara, sastra lisan | Bahasa Bali (alus, madya, kasar) |
| 9 | **Permainan Rakyat** | Permainan tradisional anak-anak dan dewasa | Megala-gala, metajen |
| 10 | **Olahraga Tradisional** | Seni bela diri, lomba tradisional | Mepantigan, peresean |

### 1.2 Pemajuan Kebudayaan — 4 Pilar

Sesuai UU No.5/2017, pemajuan kebudayaan mencakup:

1. **Pelindungan** — menjaga keberlanjutan OPK
2. **Pengembangan** — memperkaya keberagaman
3. **Pemanfaatan** — memperkuat identitas dan kesejahteraan
4. **Pembinaan** — meningkatkan kualitas SDM dan lembaga

SIOPK berfokus pada **pilar pertama**: Pelindungan — melalui inventarisasi digital dan pemetaan.

---

## 2. Konteks Geografis

### 2.1 Kabupaten Badung

| Data | Nilai |
|------|-------|
| Ibu kota | Mangupura |
| Luas wilayah | 418,62 km² |
| Jumlah kecamatan | 6 (Petang, Abiansemal, Mengwi, Kuta Utara, Kuta, Kuta Selatan) |
| Jumlah desa dinas | 62 desa/kelurahan |
| Jumlah desa adat | ±50 desa adat |
| Penduduk | ±548.000 jiwa |

### 2.2 Karakteristik Budaya

Badung memiliki kekhasan budaya:
- **Badung selatan**: Pariwisata (Kuta, Nusa Dua), budaya populer, tarian turistik
- **Badung tengah**: Transisi urban-rural, pertanian, kerajinan
- **Badung utara**: Agraris (Petang, Abiansemal), budaya tradisional lebih kuat, subak

Sistem harus mengakomodasi keragaman ini — dari OPK urban (seni turistik) hingga rural (manuskrip kuno di desa pegunungan).

---

## 3. Konteks Organisasional

### 3.1 Stakeholder Pengguna

```
Dinas Kebudayaan Kabupaten Badung
├── Kepala Dinas ────────────── Dashboard Eksekutif
├── Kabid Kebudayaan ────────── Supervisi verifikasi
├── Seksi Pelindungan ───────── Verifikator
├── Seksi Pengembangan ──────── Input data tambahan
├── Petugas Lapangan ────────── Survey GPS, foto lapangan
└── Staff Admin ─────────────── Manajemen data, ekspor
```

### 3.2 Role-Based Access Control (RBAC)

| Role | Hak Akses |
|------|----------|
| **superadmin** | Semua akses (termasuk manajemen user & hapus permanen) |
| **admin** | CRUD OPK, verifikasi, manajemen user (kecuali superadmin), AI tools |
| **verifikator** | Melihat antrian, approve/reject laporan |
| **petugas** | Melihat data OPK & dashboard (read-only) |
| **publik** | Submit laporan, cek status, lihat peta publik |

---

## 4. Konteks Teknologi

### 4.1 Mengapa Laravel 11?

| Faktor | Justifikasi |
|--------|------------|
| **Ekosistem PHP** | XAMPP tersedia di Windows (lingkungan dosen/mahasiswa) |
| **Produktivitas** | Eloquent ORM, Blade templating, Artisan CLI — rapid development |
| **Keamanan built-in** | CSRF, XSS, SQL injection protection, hashing |
| **Komunitas** | Dokumentasi luas, Stack Overflow, tutorial Bahasa Indonesia |
| **Hosting murah** | Shared hosting PHP masih dominan di Indonesia |
| **LTS** | Laravel 11 LTS, security patch hingga 2026 |

### 4.2 Mengapa Tidak React / Vue / Inertia?

| Trade-off | Justifikasi |
|-----------|------------|
| **Kompleksitas** | Tim mahasiswa — Blade server-side lebih sederhana |
| **Build step** | Tidak perlu Node.js/npm di XAMPP (tanpa Vite setup kompleks) |
| **SEO** | Blade SSR — semua konten terindeks Google |
| **Offline** | Tidak ada SPA hydration issue |

---

## 5. Domain Glossary

| Istilah | Definisi |
|---------|----------|
| **OPK** | Objek Pemajuan Kebudayaan — 10 jenis warisan budaya sesuai UU No.5/2017 |
| **Desa Adat** | Kesatuan masyarakat hukum adat di Bali (bukan administratif) |
| **Desa Dinas** | Desa administratif (pemerintahan formal) |
| **Kecamatan** | Wilayah administratif di bawah kabupaten |
| **Laporan** | Data OPK yang dikirim masyarakat via form 5 langkah |
| **Verifikasi** | Proses validasi laporan oleh Dinas Kebudayaan |
| **Urgency Score** | Skor 0–10 dari AI yang mengukur urgensi pelindungan |
| **Duplikat Score** | Persentase kemiripan dengan laporan lain (0–100%) |
| **Kode Laporan** | ID unik format `SIOPK-YYYY-NNNNN` untuk tracking publik |
| **Kondisi** | Status fisik OPK: `baik`, `waspada`, `kritis` |
| **Status Pelindungan** | Level legal: `belum_terdaftar` hingga `wbtb_nasional` |
| **Ringkasan Eksekutif** | Laporan mingguan AI untuk Kepala Dinas |
| **Prioritas Pemeliharaan** | OPK dengan urgency score ≥ 7 (butuh tindakan segera) |
