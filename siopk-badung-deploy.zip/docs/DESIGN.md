# DESIGN — System Design Document

## SIOPK Badung — Desain Teknis

**Versi**: 1.0  
**Tanggal**: Juni 2026

---

## 1. Arsitektur Sistem

### 1.1 Pattern: Modular Monolith

```
┌────────────────────────────────────────────────────┐
│                   PRESENTATION                     │
│  Blade Templates + Bootstrap 5 + Leaflet.js        │
│  Publik: 5 views │ Admin: 15 views                 │
└──────────────────────┬─────────────────────────────┘
                       │ HTTP (Server-rendered HTML)
┌──────────────────────▼─────────────────────────────┐
│                   ROUTING                          │
│  routes/web.php (Publik + Admin groups)            │
│  Middleware: auth, role, throttle, csrf            │
└──────────────────────┬─────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────┐
│                   CONTROLLERS                      │
│  Admin\ (8) │ Publik\ (2)                          │
│  Thin controllers → delegate ke Services            │
└──────────────────────┬─────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────┐
│                   SERVICES (Domain Logic)           │
│  AiOpkAnalyzer │ OpkStatsService │ PetaDataService  │
│  LaporanService │ VerifikasiService │ OpkMediaService │
│  WhatsAppService (Fonnte API)                      │
│  Validation: 3 Form Request classes                │
└──────────────────────┬─────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────┐
│                   EVENTS & JOBS                    │
│  Events: LaporanCreated, LaporanVerified,          │
│          AiAnalysisCompleted                       │
│  Listeners: SideEffectHandler (cache invalidation) │
│  Jobs: AnalisisOpkJob (AI analysis)                │
└──────────────────────┬─────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────┐
│                   DATA ACCESS                      │
│  Eloquent ORM (10 Models + Relations + Scopes)     │
│  Observers: OpkLaporanObserver (file cleanup)      │
└──────────────────────┬─────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────┐
│                   DATA STORE                       │
│  MySQL 8 (single) │ Filesystem (local)             │
│  Cache: file/database │ Session: file/database     │
└────────────────────────────────────────────────────┘
```

### 1.2 Design Decisions (ADR)

#### ADR-01: Laravel Monolith over Microservices

| Aspek | Detail |
|-------|--------|
| **Decision** | Monolith Laravel 11 |
| **Context** | Tim 1–2 developer, skala kabupaten, budget nol |
| **Alternatives** | Microservices, Serverless, SPA + API |
| **Rationale** | Kompleksitas tidak sebanding. Monolith mudah di-deploy, debug, dan maintain oleh tim kecil. Service layer sudah dipisah — refactor ke microservices bisa dilakukan jika diperlukan. |
| **Trade-off** | Scaling terbatas ke 1 server. Tapi skala kabupaten tidak butuh horizontal scaling. |

#### ADR-02: Blade SSR over SPA (Vue/React)

| Aspek | Detail |
|-------|--------|
| **Decision** | Server-side rendering dengan Blade + Bootstrap 5 |
| **Context** | Tidak ada frontend developer, XAMPP tanpa Node.js |
| **Alternatives** | Inertia.js + Vue, Livewire, REST API + SPA |
| **Rationale** | Zero build step, SEO-friendly, `@auth` directive langsung di template. Leaflet.js ditambahkan via CDN untuk interaktivitas peta. |
| **Trade-off** | Kurang interaktif dibanding SPA. Tapi form wizard dan peta sudah cukup dengan vanilla JS. |

#### ADR-03: Multi-Provider AI via Config over Interface

| Aspek | Detail |
|-------|--------|
| **Decision** | Provider AI dikonfigurasi via `config/services.php` + `.env`, bukan via interface/strategy pattern |
| **Context** | 5 provider AI dengan API format berbeda (Anthropic vs OpenAI-compatible) |
| **Alternatives** | Strategy pattern dengan interface `AiProviderContract` + concrete classes |
| **Rationale** | Config-driven approach lebih sederhana untuk 5 provider. `isClaudeFormat()` method menangani perbedaan response format. Policy/strategy pattern overkill untuk use case ini. |
| **Trade-off** | Menambah provider yang tidak Anthropic/OpenAI-compatible perlu ubah kode. |

#### ADR-04: File Upload ke Local Storage

| Aspek | Detail |
|-------|--------|
| **Decision** | Upload ke `storage/app/public/`, symlink ke `public/storage/` |
| **Context** | XAMPP single server, tidak ada S3 budget |
| **Alternatives** | Cloud storage (S3, DO Spaces), CDN |
| **Rationale** | Simple, nol biaya. Struktur folder: `foto_opk/{laporan_id}/{uuid}.{ext}` |
| **Trade-off** | Tanpa backup/redundansi. Foto adalah data budaya — irreplaceable. Perlu migrasi ke cloud storage di production. |

#### ADR-05: `nama_desa_adat` as VARCHAR instead of FK

| Aspek | Detail |
|-------|--------|
| **Decision** | Desa Adat disimpan sebagai string bebas di `opk_laporans.nama_desa_adat` |
| **Context** | Desa Adat di Bali bersifat dinamis (pemekaran/penggabungan), nama bisa berubah |
| **Alternatives** | FK ke `desa_adats` table |
| **Rationale** | Masyarakat bisa mengetik nama desa adat yang belum ada di dropdown. Fleksibilitas > referential integrity. |
| **Trade-off** | Tidak bisa JOIN/aggregate by Desa Adat. Block migrasi multi-kabupaten. |

---

## 2. Database Design

### 2.1 Entity Relationship Diagram (ERD)

```
┌─────────────────┐       ┌──────────────────┐
│  opk_categories  │       │   users          │
│─────────────────│       │──────────────────│
│ id (PK)         │       │ id (PK)          │
│ nomor (UQ)      │       │ name             │
│ nama            │       │ email (UQ)       │
│ ikon            │       │ password         │
│ deskripsi       │       │ role             │
└────────┬────────┘       │ is_active        │
         │                └────────┬─────────┘
         │ 1:N                    │ 1:N
         ▼                        ▼
┌──────────────────────────────────────────────────┐
│                opk_laporans                       │
│──────────────────────────────────────────────────│
│ id (PK)                                          │
│ kode_laporan (UQ)                                │
│ nama_opk                                         │
│ kategori_id (FK → opk_categories)                │
│ kecamatan_id (FK → kecamatans)                   │
│ desa_dinas_id (FK → desa_dinas)                  │
│ nama_desa_adat (VARCHAR)  ← denormalized         │
│ kondisi (ENUM: baik, waspada, kritis)            │
│ status_pelindungan (ENUM)                        │
│ status_verifikasi (ENUM)                         │
│ diverifikasi_oleh (FK → users)                   │
│ latitude, longitude (FLOAT)                      │
│ deskripsi_umum, sejarah_asal_usul, ...           │
│ ai_urgency_score, ai_duplikat_score, ...         │
│ pelapor_nama, pelapor_nik, pelapor_whatsapp, ... │
│ created_at, updated_at, deleted_at (soft delete) │
└───┬──────────────┬────────────────┬──────────────┘
    │ 1:N          │ 1:N            │ 1:N
    ▼              ▼                ▼
┌──────────┐ ┌──────────┐ ┌──────────────────┐
│opk_fotos │ │opk_dokums│ │opk_riwayat_status│
│──────────│ │──────────│ │──────────────────│
│laporan_id│ │laporan_id│ │ laporan_id (FK)  │
│path      │ │path      │ │ status_lama       │
│is_utama  │ │jenis     │ │ status_baru       │
│urutan    │ │judul     │ │ user_id (FK)      │
└──────────┘ └──────────┘ │ catatan           │
                          └──────────────────┘
         ┌──────────────────┐
         │ opk_videos       │
         │──────────────────│
         │ laporan_id (FK)  │
         │ link_eksternal   │
         └──────────────────┘

┌───────────┐    ┌───────────┐    ┌───────────┐
│kecamatans │    │desa_dinas │    │desa_adats │
│───────────│    │───────────│    │───────────│
│ id (PK)   │◄───│kecamatan_id│◄──│kecamatan_id│
│ nama      │    │ nama      │    │ nama      │
│ kode      │    │ kode      │    │ banjar_adat│
└───────────┘    └───────────┘    └───────────┘
```

### 2.2 Table Sizes & Indexing

| Tabel | Estimasi Records | Indexes |
|-------|-----------------|---------|
| `opk_categories` | 10 | PK, UQ(nomor) |
| `kecamatans` | 6 | PK |
| `desa_dinas` | 62 | PK, FK(kecamatan_id) |
| `desa_adats` | ~50 | PK, FK(kecamatan_id) |
| `users` | 10–50 | PK, UQ(email) |
| `opk_laporans` | 5000 | PK, UQ(kode_laporan), IDX(status_verifikasi), IDX(kondisi), IDX(kecamatan_id), IDX(kategori_id), IDX(created_at), FK×5 |
| `opk_fotos` | 50.000 | PK, FK(laporan_id), IDX(is_utama) |
| `opk_dokumens` | 5.000 | PK, FK(laporan_id) |
| `opk_videos` | 5.000 | PK, FK(laporan_id) |
| `opk_riwayat_status` | 25.000 | PK, FK(laporan_id), FK(user_id) |
| `jobs` | < 100 | PK, IDX(queue) |
| `failed_jobs` | < 10 | PK, UQ(uuid) |

**Recommended Future Indexes:**
- `(status_verifikasi, kondisi)` — composite untuk dashboard KPI
- `(status_verifikasi, ai_urgency_score)` — composite untuk priority list
- `(latitude, longitude)` — spatial index untuk query radius

---

## 3. API / Route Design

### 3.1 Route Groups

```
Publik (no auth):
  GET   /                          → DashboardPublikController@index
  GET   /peta/data                 → DashboardPublikController@petaJson
  GET   /opk/{opk}                 → DashboardPublikController@showOpk
  GET   /lapor                     → LaporController@index
  POST  /lapor/kirim               → LaporController@store       [throttle:3,1]
  GET   /lapor/sukses              → LaporController@sukses
  GET   /lapor/status              → LaporController@cekStatus
  GET   /api/desa-dinas            → LaporController@getDesaDinas
  GET   /api/desa-adat             → LaporController@getDesaAdat

Auth:
  GET   /login                     → AuthController@showLogin
  POST  /login                     → AuthController@login         [throttle:5,1]
  POST  /logout                    → AuthController@logout

Admin (auth + role middleware):
  GET   /admin/dashboard           → DashboardController@index
  GET   /admin/opk                 → OpkController@index
  GET   /admin/opk/arsip           → OpkController@arsip
  GET   /admin/opk/{laporan}       → OpkController@show
  GET   /admin/opk/{laporan}/edit  → OpkController@edit
  PUT   /admin/opk/{laporan}       → OpkController@update
  DELETE /admin/opk/{laporan}      → OpkController@destroy
  POST  /admin/opk/{id}/restore    → OpkController@restore
  POST  /admin/opk/{id}/force-delete → OpkController@forceDelete
  GET   /admin/peta/data           → OpkController@petaJson
  
  GET   /admin/verifikasi          → VerifikasiController@index
  GET   /admin/verifikasi/{laporan}  → VerifikasiController@show
  POST  /admin/verifikasi/{laporan}/setujui → VerifikasiController@setujui
  POST  /admin/verifikasi/{laporan}/tolak   → VerifikasiController@tolak
  
  GET   /admin/laporan             → LaporanAdminController@index
  GET   /admin/laporan/export      → LaporanAdminController@exportCsv
  
  GET   /admin/pengguna            → PenggunaController@index
  POST  /admin/pengguna            → PenggunaController@store
  PUT   /admin/pengguna/{pengguna} → PenggunaController@update
  
  POST  /admin/ai/chat/{laporan}   → AiController@chat          [throttle:10,1]
  POST  /admin/ai/re-analisis/{laporan} → AiController@reAnalisis
  GET   /admin/ai/ringkasan        → AiController@ringkasanEksekutif [throttle:5,1]
  GET   /admin/ai/ringkasan-halaman → view
  POST  /admin/ai/klasifikasi      → AiController@klasifikasi    [throttle:20,1]
  POST  /admin/ai/clear-cache      → AiController@clearRingkasanCache
```

### 3.2 Peta JSON Response Format

#### Admin Endpoint: `GET /admin/peta/data`

```json
[
  {
    "id": 1,
    "kode": "SIOPK-2025-00001",
    "nama": "Tari Barong",
    "kondisi": "baik",
    "lat": -8.650000,
    "lng": 115.180000,
    "kategori": "Seni",
    "ikon_kategori": "🎭",
    "kecamatan": "Mengwi",
    "desa_adat": "Desa Adat Mengwi",
    "urgency_score": 4.5,
    "foto_url": "http://localhost/storage/foto_opk/1/uuid.jpg",
    "detail_url": "http://localhost/admin/opk/1"
  }
]
```

#### Publik Endpoint: `GET /peta/data`

```json
[
  {
    "id": 1,
    "nama": "Tari Barong",
    "kondisi": "baik",
    "lat": -8.650000,
    "lng": 115.180000,
    "kategori": "Seni",
    "ikon": "🎭",
    "kec": "Mengwi",
    "desa": "Desa Adat Mengwi",
    "foto": "http://localhost/storage/foto_opk/1/uuid.jpg",
    "url": "http://localhost/opk/1"
  }
]
```

---

## 4. Component Design

### 4.1 Service Layer

```
app/Services/
├── AiOpkAnalyzer.php      # Multi-provider AI analysis
│   ├── analisisLaporan()  # Full analysis with urgency + duplicate
│   ├── cekDuplikat()      # Pairwise duplicate check
│   ├── ringkasanEksekutif() # Weekly executive summary
│   ├── klasifikasiOtomatis() # Auto-categorize OPK
│   ├── chatAsisten()      # Contextual Q&A for verifikator
│   ├── sanitize()         # Strip control chars, truncate
│   └── defaultAnalysis()  # Fallback when AI unavailable
├── OpkStatsService.php    # Statistics aggregation
│   ├── dashboardAdmin()   # Admin KPI stats
│   ├── dashboardPublik()  # Public KPI stats
│   ├── laporanAdmin()     # Report page stats
│   └── ringkasanEksekutif() # AI input stats
├── PetaDataService.php    # Map data query + format
│   ├── getPetaData()      # Filtered map markers
│   └── formatMarker()     # Admin vs Publik JSON format
├── LaporanService.php     # Laporan creation logic
│   ├── createLaporan()    # Create OpkLaporan record
│   ├── uploadFotos()      # Multi-photo upload
│   ├── uploadDokumen()    # Document upload
│   └── saveVideoLink()    # External video link
├── OpkMediaService.php    # OPK media management
│   ├── deleteFotos()      # Delete photos + storage
│   ├── uploadFotos()      # Upload with quota check
│   └── setFotoUtama()     # Reassign primary photo
├── VerifikasiService.php  # Verification workflow
│   ├── setujuiLaporan()   # Approve report
│   └── tolakLaporan()     # Reject with reason
├── WhatsAppService.php    # Fonnte WhatsApp API
│   ├── notifikasiLaporanDiterima()  # New report notification
│   ├── notifikasiLaporanDisetujui() # Approval notification
│   └── notifikasiLaporanDitolak()   # Rejection notification
│
app/Services/Ai/           # AI Provider Strategy Pattern
├── AiProviderInterface.php     # analyze(prompt, maxTokens): array
├── AiProviderFactory.php       # Resolve provider by config
├── BaseProvider.php            # Shared HTTP + retry logic
├── ClaudeProvider.php          # Anthropic API (x-api-key)
├── OpenAiProvider.php          # OpenAI API (Bearer)
├── DeepSeekProvider.php        # DeepSeek API (Bearer)
├── GroqProvider.php            # Groq API (Bearer)
├── OpenAiCompatibleProvider.php# Shared OpenAI-format response
└── CustomProvider.php          # Custom endpoint (Ollama, LM Studio)
```

### 4.2 Event Flow

```
Laporan dibuat (LaporController@store)
  │
  ├─► AnalisisOpkJob::dispatch($laporan_id)
  │     └─► handle(AiOpkAnalyzer)
  │           ├─► update status: menunggu → ai_review
  │           ├─► analisisLaporan() → AI API call
  │           ├─► update: ai_urgency_score, ai_rekomendasi, ...
  │           └─► AiAnalysisCompleted::dispatch()
  │
  └─► LaporanCreated::dispatch($laporan)
        └─► SideEffectHandler::handleLaporanCreated()
              └─► Cache::forget(SIDEBAR_COUNTS, RINGKASAN_EKSEKUTIF)

Laporan diverifikasi (VerifikasiController)
  │
  └─► LaporanVerified::dispatch($laporan, $statusBaru)
        └─► SideEffectHandler::handleLaporanVerified()
              └─► Cache::forget(SIDEBAR_COUNTS, RINGKASAN_EKSEKUTIF)
```

### 4.3 Job Lifecycle

```
AnalisisOpkJob
  │  tries: 3, timeout: 60s, backoff: [1, 5, 10]
  │
  ├─► handle(AiOpkAnalyzer $ai)
  │     ├─► find laporan by ID
  │     │     ├─► not found → return (laporan dihapus)
  │     │     └─► found → lanjut
  │     ├─► update status → ai_review
  │     ├─► $ai->analisisLaporan($laporan)
  │     ├─► update laporan (scores, rekomendasi)
  │     ├─► update status → review_dinas
  │     └─► AiAnalysisCompleted::dispatch()
  │
  └─► failed(\Throwable $e)
        ├─► update status → review_dinas (manual verification)
        └─► log error
```

---

## 5. Design System — CSS Variables

### 5.1 Color Palette (Balinese-Inspired)

```css
:root {
    --tanah:       #2C1A0E;   /* Dark brown — text, sidebar background */
    --emas:        #C8922A;   /* Gold — primary action, borders */
    --emas-muda:   #E8B84B;   /* Light gold — hover states */
    --krem:        #F7F1E8;   /* Cream — page background */
    --hijau:       #2D5A27;   /* Green — status: baik */
    --merah:       #C0392B;   /* Red — status: kritis */
    --kuning:      #D4A017;   /* Yellow — status: waspada */

    /* RGB variants for rgba() usage */
    --emas-rgb:    200,146,42;
    --merah-rgb:   192,57,43;
    --kuning-rgb:  212,160,23;
    --hijau-rgb:   45,90,39;
}
```

### 5.2 Typography

| Element | Font | Weight | Size |
|---------|------|--------|------|
| Headings | Cormorant Garamond | 600–700 | 1.2–2.4rem |
| Body | Inter | 400–500 | 0.82rem |
| Meta / Labels | Inter | 600–700 | 0.68–0.72rem |
| Sidebar | Inter | 400 | 0.83rem |
| KPI Numbers | Cormorant Garamond | 700 | 2.4rem |

### 5.3 JavaScript Color Constants

```javascript
// Read from CSS custom properties at init time
const ds = {
    merah:  getComputedStyle(document.documentElement).getPropertyValue('--merah').trim(),
    kuning: getComputedStyle(document.documentElement).getPropertyValue('--kuning').trim(),
    hijau:  getComputedStyle(document.documentElement).getPropertyValue('--hijau').trim(),
    emas:   getComputedStyle(document.documentElement).getPropertyValue('--emas').trim(),
};
```

---

## 6. Deployment Architecture

### 6.1 Development (Current — XAMPP / php artisan serve)

```
Windows/Linux PC
├── PHP built-in server (php artisan serve) / Apache
│     └── Laravel 11
├── MySQL 8
├── File storage: storage/
└── Scheduler: php artisan schedule:run (every 1 min)
```

### 6.2 Production — Docker Compose (Linux VPS)

```yaml
# docker-compose.yml — active
services:
  app:
    build: .              # Dockerfile with PHP extensions
    volumes: [.:/var/www/html]
  nginx:
    image: nginx:alpine
    ports: ["80:80", "443:443"]
  mysql:
    image: mysql:8.0
    volumes: [mysql_data:/var/lib/mysql]
  redis:
    image: redis:7-alpine
  worker:
    build: .              # Same Dockerfile, runs queue:work
    command: php artisan queue:work --sleep=3 --tries=3
  scheduler:
    build: .              # Same Dockerfile, runs schedule:work
    command: php artisan schedule:work
```

**Key differences from development:**
- Nginx + PHP-FPM (bukan php artisan serve) — concurrent request handling
- Redis untuk session + cache (bukan database/file)
- Dedicated queue worker container — AI jobs + WhatsApp async, no HTTP blocking
- MySQL volume mount — data persistensi
- Let's Encrypt SSL — HTTPS enforced
- Fonnte WhatsApp API — notifikasi ke pelapor via queue job

---

## 7. Security Architecture

```
┌──────────────────────────────────────────────────┐
│ Layer 1 — Network                                │
│  • HTTPS (production)                            │
│  • Rate limiting: 3-20 req/min per endpoint      │
│  • SESSION_SECURE_COOKIE=true (production)       │
└──────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────┐
│ Layer 2 — Authentication                         │
│  • Laravel session-based auth                    │
│  • Password: Bcrypt hashed cast                  │
│  • Session regeneration on login                 │
│  • is_active flag check                          │
│  • Login throttling: 5 attempts/min              │
└──────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────┐
│ Layer 3 — Authorization                          │
│  • RoleMiddleware (5 roles: string-based RBAC)   │
│  • Route group middleware di web.php             │
│  • View-level checks: @can, auth()->user()->isXxx│
└──────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────┐
│ Layer 4 — Application                            │
│  • Input validation: Form Request classes        │
│  • CSRF: @csrf di semua form                     │
│  • XSS: Blade {{ }} auto-escaping                │
│  • SQLi: Eloquent ORM, no raw queries w/ input   │
│  • File upload: MIME validation, UUID filenames  │
│  • AI prompt: sanitize() strips control chars    │
└──────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────┐
│ Layer 5 — Data                                   │
│  • .env not committed                            │
│  • API keys via config() not env() in code       │
│  • Model::shouldBeStrict() in dev                │
└──────────────────────────────────────────────────┘
```
