# SRS — Software Requirements Specification

## SIOPK Badung — Spesifikasi Kebutuhan Perangkat Lunak

**Versi**: 1.0  
**Tanggal**: Juni 2026  
**Standar**: IEEE 830-1998

---

## 1. Pendahuluan

### 1.1 Tujuan

Dokumen ini mendefinisikan kebutuhan fungsional dan non-fungsional Sistem Informasi Objek Pemajuan Kebudayaan (SIOPK) Kabupaten Badung. Dokumen digunakan sebagai acuan pengembangan, pengujian, dan validasi sistem.

### 1.2 Lingkup

Sistem berbasis web yang mencakup:
- Portal publik: form laporan, peta interaktif, cek status
- Panel admin: dashboard, verifikasi, manajemen data, analisis AI
- Background jobs: analisis AI otomatis, scheduled tasks

### 1.3 Definisi & Akronim

Lihat [Domain Glossary](CONTEXT.md#5-domain-glossary).

---

## 2. Kebutuhan Fungsional

### 2.1 Portal Publik

#### FR-01: Form Laporan Multi-Step

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Masyarakat dapat melaporkan OPK melalui form 5 langkah |
| **Actor** | Publik |
| **Precondition** | Halaman `/lapor` dapat diakses |
| **Flow** | 1. Step 1: Identitas OPK (nama, jenis, kondisi, status pelindungan) 2. Step 2: Lokasi (kecamatan, desa dinas, desa adat, GPS) 3. Step 3: Deskripsi Budaya (deskripsi umum, sejarah, makna, bahasa, praktisi) 4. Step 4: Media Upload (foto, video, dokumen pendukung) 5. Step 5: Data Pelapor (tipe, nama, NIK, WhatsApp, persetujuan) |
| **Postcondition** | Laporan tersimpan, kode unik diberikan, AI job dispatched |
| **Validation** | Semua required field wajib diisi, foto max 2MB JPG/PNG, NIK 16 digit, deskripsi min 50 karakter |
| **Error Handling** | Validasi server-side dengan pesan Bahasa Indonesia. Gagal = rollback + flash error |

#### FR-02: Peta Publik Interaktif

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Peta Leaflet menampilkan semua OPK yang telah disetujui |
| **Actor** | Publik |
| **Precondition** | Halaman `/` dapat diakses |
| **Features** | Marker berwarna berdasarkan kondisi (merah/kuning/hijau), popup detail, filter kondisi/kategori/kecamatan, search nama OPK, klik marker → fly to + highlight sidebar |
| **Data** | Hanya OPK dengan `status_verifikasi = disetujui` + koordinat valid (≠ 0,0) |

#### FR-03: Cek Status Laporan

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Pelapor dapat memantau status laporan via kode unik |
| **Actor** | Publik |
| **Precondition** | Memiliki kode laporan (format `SIOPK-YYYY-NNNNN`) |
| **Response** | Status verifikasi + riwayat status |

### 2.2 Autentikasi & Otorisasi

#### FR-04: Login & Logout

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Admin/verifikator login dengan email + password |
| **Actor** | Superadmin, Admin, Verifikator, Petugas |
| **Precondition** | Akun terdaftar & `is_active = true` |
| **Security** | Rate limit 5 attempts/menit, session regeneration, CSRF protection |

#### FR-05: Role-Based Access Control

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Setiap role memiliki akses berbeda ke fitur admin |
| **Roles** | superadmin > admin > verifikator > petugas |
| **Enforcement** | `RoleMiddleware` di route group, guard di view Blade |

### 2.3 Panel Verifikasi

#### FR-06: Antrian Verifikasi

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Verifikator melihat daftar laporan menunggu verifikasi |
| **Actor** | Superadmin, Admin, Verifikator |
| **Query** | `status_verifikasi IN (menunggu, ai_review, review_dinas)` |
| **Sorting** | Urgency score descending, created_at ascending |

#### FR-07: Approve Laporan

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Verifikator menyetujui laporan, OPK masuk peta resmi |
| **Actor** | Superadmin, Admin, Verifikator |
| **Flow** | 1. Input catatan verifikasi (opsional) 2. Status → `disetujui` 3. `tanggal_verifikasi = now()` 4. `diverifikasi_oleh = auth()->id()` 5. Riwayat status tercatat 6. Event `LaporanVerified` dispatched |
| **Postcondition** | OPK muncul di peta publik |

#### FR-08: Tolak Laporan

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Verifikator menolak laporan dengan alasan |
| **Actor** | Superadmin, Admin, Verifikator |
| **Alasan** | `tidak_valid`, `duplikat`, `kurang_data`, `diluar_wilayah`, `lainnya` |
| **Flow** | 1. Pilih alasan penolakan 2. Catatan wajib diisi 3. Status → `ditolak` atau `duplikat` 4. Riwayat status tercatat 5. Event `LaporanVerified` dispatched |

### 2.4 Analisis AI

#### FR-09: Auto-Analisis Laporan Baru

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Setiap laporan baru otomatis dianalisis AI via background job |
| **Actor** | System (AnalisisOpkJob) |
| **Trigger** | Setelah `LaporController@store` commit |
| **Output** | `urgency_score` (0–10), `duplikat_score` (0–100%), `duplikat_id`, `rekomendasi`, `alasan_urgensi`, `saran_verifikasi` |
| **Fallback** | Jika AI gagal → `defaultAnalysis()` berdasarkan kondisi + usia praktisi |

#### FR-10: Multi-Provider AI

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Sistem mendukung multiple AI provider via konfigurasi |
| **Providers** | Claude, OpenAI, DeepSeek, Groq, Custom |
| **Switch** | Ubah `AI_PROVIDER` di `.env`, tidak perlu ubah kode |

#### FR-11: Ringkasan Eksekutif AI

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | AI generate laporan mingguan untuk Kepala Dinas |
| **Actor** | Superadmin, Admin |
| **Cache** | 6 jam (21.600 detik) |
| **Access** | AJAX endpoint `/admin/ai/ringkasan` |

### 2.5 Dashboard Eksekutif

#### FR-12: KPI Dashboard

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Dashboard dengan Key Performance Indicators |
| **Actor** | Semua role admin |
| **Metrics** | Total OPK, kritis, menunggu verifikasi, terlindungi, laporan bulan ini |
| **Cache** | Per-user, 60 detik |

#### FR-13: Peta Admin

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Peta Leaflet dengan filter kondisi |
| **Actor** | Semua role admin |
| **Features** | Marker dengan popup detail (nama, kategori, kecamatan, desa adat, link detail) |

### 2.6 Manajemen Data

#### FR-14: CRUD OPK

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Admin dapat melihat, mengedit, mengarsipkan OPK |
| **Actor** | Superadmin, Admin |
| **Edit Fields** | Nama, kondisi, status pelindungan, deskripsi, sejarah, makna, GPS |
| **Foto Management** | Upload baru, hapus, ganti foto utama |

#### FR-15: Manajemen Pengguna

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Admin dapat menambah, mengedit, menonaktifkan, menghapus user |
| **Actor** | Superadmin, Admin |
| **Constraint** | Tidak bisa edit/hapus superadmin lain; tidak bisa nonaktifkan diri sendiri |

#### FR-16: Ekspor CSV

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Export data OPK terverifikasi ke CSV |
| **Actor** | Semua role admin |
| **Implementation** | Streaming response dengan `cursor()` untuk memory efficiency |
| **Columns** | Kode, Nama OPK, Jenis, Kondisi, Kecamatan, Desa Dinas, Desa Adat, GPS, Status, AI Score, Tanggal |

### 2.7 Scheduled Tasks

#### FR-17: Analisis Batch Otomatis

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Command `siopk:analisis-semua` setiap 30 menit |
| **Target** | Laporan dengan `ai_urgency_score IS NULL` |
| **Options** | `--force` untuk re-analisis semua |

#### FR-18: Cache Cleanup

| Atribut | Nilai |
|---------|-------|
| **Deskripsi** | Hapus cache ringkasan eksekutif mingguan |
| **Schedule** | Setiap Senin 07:00 WITA |

---

## 3. Kebutuhan Non-Fungsional

### 3.1 Performance

| NFR | Target | Measurement |
|-----|--------|------------|
| **Page load time** | < 2 detik (P95) | Browser DevTools, Laravel Debugbar |
| **API response (peta JSON)** | < 500ms (P95) untuk < 1000 markers | Network tab |
| **AI analysis time** | < 30 detik (timeout) | Job log |
| **Concurrent users** | 20 users tanpa degradasi signifikan | Load test (k6/Artillery) |
| **Database queries per page** | < 15 queries (N+1 detection enabled) | Laravel Debugbar |

### 3.2 Reliability

| NFR | Target |
|-----|--------|
| **Availability** | 99% (SLA kelas kabupaten, non-critical) |
| **Data durability** | Backup database harian (mysqldump), backup file mingguan |
| **Graceful degradation** | AI gagal → fallback analisis manual; CDN gagal → blank (future: local assets) |
| **Error handling** | Semua exception tercatch, transaction rollback, user-friendly message |

### 3.3 Security

| NFR | Implementation |
|-----|---------------|
| **Authentication** | Laravel session-based, rate limited (5/min), session regeneration |
| **Authorization** | Role middleware (5 roles), `is_active` check |
| **CSRF** | `@csrf` di semua form POST/PUT/DELETE |
| **XSS** | Blade auto-escaping `{{ }}` |
| **SQL Injection** | Eloquent ORM, parameterized queries |
| **File upload** | MIME validation, size limit (2MB), UUID filenames |
| **Password** | Bcrypt via `hashed` cast |
| **HTTPS** | Required for production (`SESSION_SECURE_COOKIE=true`) |
| **Secrets** | `.env` tidak di-commit |

### 3.4 Maintainability

| NFR | Target |
|-----|--------|
| **Code style** | PSR-12, Laravel conventions |
| **Test coverage** | Unit tests untuk models, feature tests untuk controllers |
| **Documentation** | README installation, CHANGELOG, CONTEXT, PRD, SRS, DESIGN |
| **Logging** | Structured logging dengan context arrays, `Log::info/error` |

### 3.5 Compatibility

| NFR | Target |
|-----|--------|
| **Browser** | Chrome, Firefox, Edge (versi terkini) |
| **Mobile browser** | Responsive design (Bootstrap 5), form works on mobile |
| **PHP** | 8.2+ |
| **Database** | MySQL 8.0+ / MariaDB 10.3+ / SQLite (testing) |
| **OS** | Windows (XAMPP dev), Linux (production target) |

---

## 4. Use Cases

### UC-01: Masyarakat Melaporkan OPK

```
Actor: Masyarakat
Precondition: Akses internet, tahu lokasi OPK

1. Buka halaman /lapor
2. Isi Step 1 (nama, jenis, kondisi)
3. Isi Step 2 (kecamatan, desa, GPS via klik peta)
4. Isi Step 3 (deskripsi budaya, sejarah, praktisi)
5. Isi Step 4 (upload foto, link video, dokumen)
6. Isi Step 5 (identitas pelapor, persetujuan)
7. Submit
8. Sistem validasi → simpan → dispatch AI job
9. Tampilkan halaman sukses dengan KODE LAPORAN
10. Pelapor catat kode untuk cek status

Alternative flow:
  7a. Validasi gagal → tampilkan error di field terkait
  7b. File terlalu besar → pesan "Foto maksimal 2MB"
```

### UC-02: Verifikator Menyetujui Laporan

```
Actor: Verifikator
Precondition: Login sebagai verifikator/admin

1. Buka /admin/verifikasi
2. Lihat antrian (diurutkan urgency score)
3. Klik laporan → tampil detail lengkap
4. Review foto, deskripsi, AI score & rekomendasi
5. Klik "Setujui" → input catatan (opsional) → konfirmasi
6. Status → disetujui, OPK masuk peta publik
7. Cache di-refresh otomatis via event listener
```

### UC-03: Kepala Dinas Melihat Ringkasan

```
Actor: Kepala Dinas (Admin/Superadmin)
Precondition: Login

1. Buka /admin/dashboard
2. Lihat KPI cards (total, kritis, waspada)
3. Lihat peta sebaran OPK
4. Buka /admin/ai/ringkasan-halaman
5. Klik "Generate Ringkasan"
6. AI generate ringkasan mingguan (cached 6 jam)
7. Tampilkan: kondisi umum, temuan penting, rekomendasi, prioritas
```

---

## 5. Data Requirements

### 5.1 Data Entities

| Entity | Tabel | Records (estimasi) | Growth Rate |
|--------|-------|-------------------|-------------|
| User | `users` | 10–50 | Rendah |
| Kategori | `opk_categories` | 10 (fixed) | Nol |
| Kecamatan | `kecamatans` | 6 (fixed) | Nol |
| Desa Dinas | `desa_dinas` | 62 (fixed) | Nol |
| Desa Adat | `desa_adats` | ~50 (fixed) | Rendah |
| Laporan OPK | `opk_laporans` | 200–5000 | ~50/bulan |
| Foto | `opk_fotos` | 2–10× laporan | ~200/bulan |
| Dokumen | `opk_dokumens` | 0–1× laporan | ~20/bulan |
| Video | `opk_videos` | 0–1× laporan | ~20/bulan |
| Riwayat Status | `opk_riwayat_status` | 3–5× laporan | ~200/bulan |

### 5.2 Data Retention

| Entity | Retention | Justifikasi |
|--------|-----------|------------|
| Laporan disetujui | Permanen | Data budaya — harus dilestarikan |
| Laporan ditolak/duplikat | Permanen (soft delete) | Audit trail |
| Foto/Dokumen | Permanen | Arsip visual budaya |
| Log file | 30 hari (daily rotation) | Storage management |
| Cache | Auto-expire (60s–86400s) | Performance |
| Session | 120 menit idle | Security |
