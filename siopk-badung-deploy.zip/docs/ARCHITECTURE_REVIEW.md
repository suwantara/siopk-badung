# SIOPK Badung — Architecture Review & Improvement Plan

> **Audit**: 25 Juni 2026 | **Updated**: 28 Juni 2026 (marked fixed items)

## Identitas Proyek

**SIOPK** (Sistem Informasi Objek Pemajuan Kebudayaan) — platform Dinas Kebudayaan Kabupaten Badung untuk pemetaan partisipatif warisan budaya berdasarkan UU No. 5 Tahun 2017.

| Layer | Teknologi |
|---|---|
| Backend | Laravel 11, PHP 8.2+ |
| Database | MySQL 8 |
| Frontend | Blade + Bootstrap 5 + Tailwind CSS 4 |
| Peta/GIS | Leaflet.js + OpenStreetMap |
| AI | Multi-provider: Claude, OpenAI, DeepSeek, Groq, Custom |
| WhatsApp | Fonnte API |
| Build Tool | Vite 7 |

---

## Temuan Kritis (Harus Diperbaiki)

### 1. ✅ FIXED — File Duplikat Controller
File `*Controller1.php` sudah dihapus.

### 2. Zero Test Coverage
Hanya ada stub default Laravel. Tidak ada test untuk controller, service, job, atau middleware.

### 3. ✅ FIXED — Tidak Ada Rate Limiting
Throttling sudah ditambah di `routes/web.php`:
- `login.post` → `throttle:5,1`
- `ai.*` → `throttle:10,1` / `throttle:20,1`
- `lapor.store` → `throttle:3,1`

### 4. ✅ FIXED — Exception Message Terekspos
VerifikasiController dan LaporController sudah pakai pesan generik, tidak expose `$e->getMessage()`.

### 5. ✅ FIXED — N+1 Query di Layout Sidebar
Sidebar queries sudah dipindahkan ke `SidebarComposer` dengan cache 5 menit.

### 6. ✅ FIXED — Prompt Injection Vulnerability
`AiOpkAnalyzer::sanitize()` membersihkan input sebelum masuk prompt.

### 7. Data Sensitif Tanpa Enkripsi
`pelapor_nik`, `praktisi_kontak`, `pelapor_whatsapp` masih plain text. Perlu implementasi encryption.

### 8. ✅ FIXED — Tidak Ada Form Request Classes
`StoreLaporanRequest`, `StoreUserRequest`, `UpdateOpkRequest` sudah dibuat.

### 9. ✅ FIXED — Race Condition di generateKode()
Diganti ke UUID-based: `SIOPK-YYYY-XXXXXXXX` via `Str::upper(Str::random(8))`.

### 10. ✅ FIXED — Tidak Ada Index Database
Migration `consolidated_indexes` konsolidasi 4 migration → 1: composite `(status_verifikasi, kondisi)`, `(status_verifikasi, ai_urgency_score)`, `(latitude, longitude)`, `created_at`, unique `opk_categories.nomor`.

---

## Temuan Moderate

### 11. God Model — OpkLaporan
28 field `$fillable`. Logika upload foto & media sudah diekstrak ke `OpkMediaService`. Model masih besar tapi lebih terfokus.

### 12. ✅ FIXED — Tidak Ada Events/Listeners
`LaporanCreated`, `LaporanVerified`, `AiAnalysisCompleted` events + `SideEffectHandler` listener sudah dibuat.

### 13. ✅ FIXED — Tidak Ada Authorization Policies
`OpkLaporanPolicy`, `UserPolicy` sudah ada dan diaktifkan via `$this->authorize()` di controller.

### 14. CSS Inline di Blade Templates
Masih banyak CSS inline. Dua Blade components sudah dibuat (`<x-info-row>`, `<x-foto-modal>`) tapi belum full migrate.

### 15. ✅ FIXED — Hardcoded AI Config
AI config sudah dipindahkan ke `config/services.php` dengan multi-provider support via `AiProviderInterface` strategy pattern.

### 16. ✅ FIXED — CSV Export Memory Exhaustion
`LaporanAdminController::exportCsv()` sudah pakai `cursor()`.

### 17. ✅ FIXED — Tidak Ada Caching Dashboard
Dashboard stats di-cache via `CacheKeys` constants. `DashboardController`, `LaporanAdminController`, `DashboardPublikController` semua pakai `Cache::remember()`.

### 18. Tidak Ada Vite Integration (dengan SRI)
`vite.config.js` ada tapi asset masih load dari CDN tanpa SRI hashes.

### 19. Seeder Password Hardcoded
Password di `UserSeeder` masih hardcoded.

### 20. ✅ FIXED — Tidak Ada Middleware Registration
`RoleMiddleware` sudah terdaftar, app jalan normal.

---

## Rekomendasi Perbaikan

### Prioritas 1 — Segera (Critical)
| # | Task | Status |
|---|---|---|
| 1 | Hapus semua file `*Controller1.php` | ✅ Done |
| 2 | Tambah rate limiting di login, AI, form lapor | ✅ Done |
| 3 | Sembunyikan exception message dari user | ✅ Done |
| 4 | Pindahkan sidebar badge queries ke View Composer | ✅ Done |
| 5 | Tambah database index | ✅ Done |
| 6 | Daftarkan RoleMiddleware | ✅ Done |

### Prioritas 2 — Jangka Pendek
| # | Task | Status |
|---|---|---|
| 7 | Buat Form Request classes | ✅ Done |
| 8 | Buat Authorization Policies | ✅ Done |
| 9 | Tambah caching ke dashboard & map | ✅ Done |
| 10 | Sanitasi input AI prompt | ✅ Done |
| 11 | Implement Events/Listeners | ✅ Done |
| 12 | Fix race condition `generateKode()` | ✅ Done |

### Prioritas 3 — Jangka Menengah
| # | Task | Status |
|---|---|---|
| 13 | Tulis Feature & Unit tests | Belum |
| 14 | Extract `store()` ke Service class | ✅ Done (`LaporanService`) |
| 15 | Tambah global scopes di OpkLaporan | ✅ Done |
| 16 | Pindahkan CSS ke external + Vite | Belum |
| 17 | Implementasi enkripsi data sensitif | Belum |
| 18 | Chunked CSV export | ✅ Done |
| 19 | Pindahkan AI config ke config file | ✅ Done |
| 20 | Tambah Subresource Integrity untuk CDN | Belum |

### Prioritas 4 — Jangka Panjang
| # | Task | Status |
|---|---|---|
| 21 | API versioning (`/api/v1/`) | Belum |
| 22 | Idempotency keys untuk form lapor | Belum |
| 23 | Laravel Notifications (email, WhatsApp) | ✅ Done (Fonnte) |
| 24 | Observer untuk OpkLaporan | ✅ Done |
| 25 | Spatial indexing untuk map queries | Belum |
| 26 | Component-based Blade / Livewire | ✅ Partial (2 components) |

---

## Workflow Saat Ini

```
Publik submit → status: menunggu
    ↓
AnalisisOpkJob → Claude AI (scoring + duplikat + rekomendasi)
    ↓
status: review_dinas
    ↓
Verifikator review (approve/reject)
    ↓
status: disetujui → muncul di peta publik
```

---

## Database Schema (10 tabel)

| Tabel | Fungsi |
|---|---|
| `opk_categories` | 10 kategori OPK (UU 5/2017) |
| `kecamatans` | 6 kecamatan di Badung |
| `desa_dinas` | Desa dinas per kecamatan |
| `desa_adats` | Desa adat per kecamatan |
| `users` | User dengan 5 role |
| `opk_laporans` | Tabel inti — 40+ kolom |
| `opk_fotos` | Multi-foto (max 10) |
| `opk_dokumens` | Dokumen pendukung |
| `opk_videos` | Video (lokal/YouTube) |
| `opk_riwayat_status` | Audit trail perubahan status |

---

## Role-Based Access Control

| Role | Akses |
|---|---|
| `superadmin` | Full: CRUD, verifikasi, AI, user management, archive, force-delete |
| `admin` | Dashboard, OPK CRUD, verifikasi, AI, user management |
| `verifikator` | Dashboard, OPK read, verifikasi (approve/reject), AI read/chat |
| `petugas` | Dashboard, OPK read, antrian verifikasi |
| `publik` | Portal publik saja (tanpa login) |

---

*Generated from architecture review — 25 Juni 2026*
