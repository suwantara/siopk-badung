# Design Review — Halaman Publik SIOPK Badung

**Tanggal**: 25 Juni 2026
**Platform**: Web Desktop + Mobile
**Audiens**: Masyarakat umum, tokoh adat, petugas dinas
**Paginas**: Dashboard Peta, Form Lapor, Cek Status, Detail OPK, Sukses

---

## Ringkasan Temuan

### Masalah Kritis

| # | Masalah | Impact | Halaman |
|---|---------|--------|---------|
| 1 | Empat lapis header sebelum konten utama (Nav → Hero → Stats → Map) | Tinggi | Dashboard |
| 2 | Filter tersebar di dua lokasi berbeda (stats bar + sidebar) | Tinggi | Dashboard |
| 3 | Navigasi tidak konsisten antar halaman publik | Tinggi | Semua |
| 4 | Visual hierarchy datar — semua elemen berukuran mirip | Sedang | Dashboard |
| 5 | Mobile kehilangan semua fungsionalitas filter | Sedang | Dashboard |
| 6 | AI card mengganggu di form lapor | Rendah | Lapor |
| 7 | Tiga sistem ikonografi berbeda (emoji + Bootstrap Icons + inline) | Rendah | Semua |

### Akar Masalah

1. **Tidak ada shared layout publik.** Setiap halaman meng-copy-paste HTML boilerplate + CSS + navbar. Inkonsistensi dan maintenance burden.
2. **Dashboard didesain sebagai "portal informasi" bukan "peta interaktif".** Padahal peta adalah konten utama — tapi dikubur di bawah 3 lapis informasi yang seharusnya sekunder.
3. **Filter adalah afterthought**, bukan bagian dari arsitektur informasi yang terencana.

---

## Rencana Implementasi (per Phase)

### Phase 1: Shared Public Layout
File baru: `resources/views/layouts/publik.blade.php`
- Ekstrak HTML boilerplate, CSS variables, font imports, navbar ke satu file
- Navbar konsisten: [Logo] Peta OPK | Lapor OPK | Cek Status | .. Login Dinas
- Semua halaman publik extend layout ini

### Phase 2: Dashboard Map-First Layout
- Hapus hero strip dan stats bar sebagai layer terpisah
- Stats summary jadi overlay card semi-transparan di pojok kiri atas peta
- Kategori pills pindah ke sidebar (satu tempat dengan filter lainnya)
- Section "OPK Terbaru" jadi tab kedua di sidebar

### Phase 3: Konversi Semua Halaman Publik
- `publik/dashboard.blade.php` → extends layouts.publik
- `publik/lapor.blade.php` → extends layouts.publik
- `publik/cek-status.blade.php` → extends layouts.publik
- `publik/opk-detail.blade.php` → extends layouts.publik
- `publik/lapor-sukses.blade.php` → extends layouts.publik
- `auth/login.blade.php` → extends layouts.publik (atau layout sendiri)

### Phase 4: Bersihkan Halaman Lapor
- Hapus AI info card dari sidebar kanan
- Progress sidebar tetap sebagai navigasi step

### Phase 5: Mobile Responsiveness
- Filter sebagai horizontal scrollable chips di atas peta (bukan hidden sidebar)
- OPK list sebagai bottom sheet / drawer yang bisa di-toggle dengan tombol floating
- Sidebar drawer bisa dibuka via hamburger button

### Phase 6: Standardisasi Ikonografi
- Ganti emoji navigasi (🗺) dengan Bootstrap Icons (`bi-map`)
- Ganti emoji kondisi (✅⚠️🔴) dengan ikon + warna
- Ganti emoji dekoratif (🙏) dengan ilustrasi CSS atau SVG

---

## Design Tokens (dipertahankan)

```
Warna:
  --tanah:    #2C1A0E   (coklat gelap — primary surface)
  --emas:     #C8922A   (emas — accent/CTA)
  --emas-muda:#E8B84B   (emas muda — hover)
  --krem:     #F7F1E8   (krem — background)
  --hijau:    #2D5A27   (hijau — kondisi baik)
  --merah:    #C0392B   (merah — kondisi kritis)
  --kuning:   #D4A017   (kuning — kondisi waspada)

Tipografi:
  Display: Cormorant Garamond (serif, untuk heading)
  Body:    Inter (sans-serif, untuk teks dan UI)
```

---

## Navigasi Publik (target)

```
[Logo SIOPK Badung]   Peta OPK   Lapor OPK   Cek Status   .......   Login Dinas   [Lapor Sekarang]
```

- `Peta OPK` → `route('publik.dashboard')`
- `Lapor OPK` → `route('publik.lapor.index')`
- `Cek Status` → `route('publik.lapor.status')`
- `Login Dinas` → `route('login')` (secondary style, bukan hidden)
- `Lapor Sekarang` → CTA button (hidden di halaman lapor sendiri)
